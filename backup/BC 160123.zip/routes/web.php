<?php

use App\Http\Controllers\ReimburstmentOptionController;
use App\Http\Controllers\AttendanceEmployeeController;
use App\Http\Controllers\PerformanceReviewController;
use App\Http\Controllers\Auth\AuthenticationController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DayTypeController;
use App\Http\Controllers\HRM\EmployeeController;
use App\Http\Controllers\LeaveTypeController;
use App\Http\Controllers\LoanOptionController;
use App\Http\Controllers\LeaveController;
use App\Http\Controllers\OvertimeController;
use App\Http\Controllers\OvertimeTypeController;
use App\Http\Controllers\PayslipTypeController;
use App\Http\Controllers\ReqShiftScheduleController;
use App\Http\Controllers\ShiftScheduleController;
use App\Http\Controllers\ShiftTypeController;
use App\Http\Controllers\TimeManagementReportController;
use App\Http\Controllers\TimesheetController;
use App\Http\Controllers\TravelController;
use App\Http\Controllers\UsersManagement\RolesController;
use App\Http\Controllers\UsersManagement\UsersController;
use App\Http\Controllers\AllowanceController;
use App\Http\Controllers\AllowanceOptionController;
use App\Http\Controllers\PayrollController;
use App\Http\Controllers\ReimburstController;
use App\Http\Controllers\CashController;
use App\Http\Controllers\CompanyHolidayController;
use App\Http\Controllers\DayoffController;
use App\Http\Controllers\FineController;
use App\Http\Controllers\LoanController;
use App\Http\Controllers\PaySlipController;
use App\Http\Controllers\SettingPayrollOvertimeController;
use App\Models\Dayoff;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/login', [AuthenticationController::class, 'loginView'])
        ->name('login.view')
        ->middleware('checkUserIfLogin');

Route::post('/login', [AuthenticationController::class, 'login'])
        ->name('login');

Route::post('/logout', [AuthenticationController::class, 'logout'])
        ->name('logout');

Route::get('/', [DashboardController::class, 'index'])
        ->name('dashboard')
        ->middleware('auth');



Route::resource('users', UsersController::class)->middleware('auth');
Route::resource('roles', RolesController::class)->middleware('auth');
Route::resource('employees', EmployeeController::class)->middleware('auth');

// HRM Config Master Data
Route::resource('branches', BranchController::class)->middleware('auth');
Route::resource('leave-type', LeaveTypeController::class)->middleware('auth');
Route::resource('reimbursement-option', ReimburstmentOptionController::class)->middleware('auth');
Route::resource('loan-option', LoanOptionController::class)->middleware('auth');
Route::resource('payslip-type', PayslipTypeController::class)->middleware('auth');
Route::resource('overtime-type', OvertimeTypeController::class)->middleware('auth');
Route::resource('day-type', DayTypeController::class)->middleware('auth');
Route::resource('shift-type', ShiftTypeController::class)->middleware('auth');
Route::resource('allowance-option', AllowanceOptionController::class)->middleware('auth');

//Finance
Route::resource('reimburst', ReimburstController::class)->middleware('auth');
Route::resource('cash', CashController::class)->middleware('auth');
Route::resource('allowances', AllowanceController::class)->middleware('auth');
Route::resource('loans', LoanController::class)->middleware('auth');
Route::get('set-bpjstk', [PayrollController::class, 'indexSetBpjsTk'])
        ->name('set-bpjstk.index')
        ->middleware('auth');
Route::get('set-bpjstk/{id}/edit', [PayrollController::class, 'editSetBpjsTk'])
        ->name('set-bpjstk.edit')
        ->middleware('auth');
Route::put('set-bpjstk/{id}/update', [PayrollController::class, 'updateSetBpjsTk'])
        ->name('set-bpjstk.update')
        ->middleware('auth');
Route::post('set-bpjstk', [PayrollController::class, 'storeSetBpjsTk'])
        ->name('set-bpjstk.store')
        ->middleware('auth');
Route::delete('set-bpjstk/{id}/destroy', [PayrollController::class, 'destroySetBpjsTk'])
        ->name('set-bpjstk.destroy')
        ->middleware('auth');

// Payroll
Route::resource('payroll', PayrollController::class)->middleware('auth');
Route::resource('payslips', PaySlipController::class)->middleware('auth');
Route::get('/payslips/generate-slip/{employee}', [PaySlipController::class, 'generateSlip'])
        ->name('payslips.generate-slip')
        ->middleware('auth');
Route::get('/payslips/download-pdf/{payslipEmployee}', [PaySlipController::class, 'downloadPDF'])
        ->name('payslips.downloadPDF')
        ->middleware('auth');
Route::resource('denda', FineController::class)->middleware('auth');
Route::get('/setting/bpjs-tk', [PayrollController::class, 'indexBpjsTk'])
        ->name('setting.bpjs-tk.index')
        ->middleware('auth');
Route::post('/setting/bpjs-tk', [PayrollController::class, 'storeBpjsTk'])
        ->name('setting.bpjs-tk.post')
        ->middleware('auth');
Route::get('/setting/pph21', [PayrollController::class, 'indexPph21'])
        ->name('setting.pph21.index')
        ->middleware('auth');
Route::post('/setting/pph21', [PayrollController::class, 'storePph21'])
        ->name('setting.pph21.post')
        ->middleware('auth');
Route::get('/setting/jht', [PayrollController::class, 'indexJht'])
        ->name('setting.jht.index')
        ->middleware('auth');
Route::post('/setting/jht', [PayrollController::class, 'storeJht'])
        ->name('setting.jht.post')
        ->middleware('auth');
Route::get('/setting/jkk', [PayrollController::class, 'indexJkk'])
        ->name('setting.jkk.index')
        ->middleware('auth');
Route::post('/setting/jkk', [PayrollController::class, 'storeJkk'])
        ->name('setting.jkk.post')
        ->middleware('auth');
Route::get('/setting/jkm', [PayrollController::class, 'indexJkm'])
        ->name('setting.jkm.index')
        ->middleware('auth');
Route::post('/setting/jkm', [PayrollController::class, 'storeJkm'])
        ->name('setting.jkm.post')
        ->middleware('auth');
Route::get('/setting/jp', [PayrollController::class, 'indexJp'])
        ->name('setting.jp.index')
        ->middleware('auth');
Route::post('/setting/jp', [PayrollController::class, 'storeJp'])
        ->name('setting.jp.post')
        ->middleware('auth');

// import
Route::post('import-excel-attendance', [AttendanceEmployeeController::class, 'importExcel'])->name('import.excel')->middleware('auth');


// Employees
Route::get('/employee/education/{employeeEducation}', [EmployeeController::class, 'employeeEducations'])
        ->name('employee.education')
        ->middleware('auth');

Route::post('/employee/education/{education}', [EmployeeController::class, 'deleteEducation'])
        ->name('employee.education.delete')
        ->middleware('auth');

Route::get('/employee/experience/{employeeExperience}', [EmployeeController::class, 'employeeExperiences'])
        ->name('employee.experience')
        ->middleware('auth');

Route::post('/employee/experience/delete/{experience}', [EmployeeController::class, 'deleteExperience'])
        ->name('employee.experience.delete')
        ->middleware('auth');

Route::get('/employee/family/{employeeFamily}', [EmployeeController::class, 'employeeFamily'])
        ->name('employee.family')
        ->middleware('auth');

Route::post('/employee/family/delete/{family}', [EmployeeController::class, 'deleteFamily'])
        ->name('employee.family.delete')
        ->middleware('auth');

Route::get('/employee/medical/{employeeMedical}', [EmployeeController::class, 'employeeMedical'])
        ->name('employee.family')
        ->middleware('auth');

Route::post('/employee/medical/delete/{medical}', [EmployeeController::class, 'deleteMedical'])
        ->name('employee.family.delete')
        ->middleware('auth');

// HR Management 
Route::resource('performance-review', PerformanceReviewController::class)->middleware('auth');
Route::resource('travels', TravelController::class)->middleware('auth');
Route::resource('timesheets', TimesheetController::class)->middleware('auth');
Route::post('timesheets-start-time', [TimesheetController::class, 'recordTime'])->name('timesheets.record-time')->middleware('auth');



// Time management
Route::resource('leaves', LeaveController::class)->middleware('auth');
Route::resource('overtimes', OvertimeController::class)->middleware('auth');
Route::resource('time-management-report', TimeManagementReportController::class)->middleware('auth');
Route::resource('time-management-report', TimeManagementReportController::class)->middleware('auth');
Route::post('time-management-report/export-pdf', [TimeManagementReportController::class, 'exportPdf'])->name('time-management.export')->middleware('auth');
Route::resource('request-shift-schedule', ReqShiftScheduleController::class)->middleware('auth');
Route::resource('shift-schedule', ShiftScheduleController::class)->middleware('auth');
Route::resource('attendance', AttendanceEmployeeController::class)->middleware('auth');
Route::get('bulk-attendance', [AttendanceEmployeeController::class, 'bulkAttendance'])->name('bulk-attendance.index')->middleware('auth');
Route::post('bulk-attendance', [AttendanceEmployeeController::class, 'bulkAttendanceData'])->name('bulk-attendance.index')->middleware('auth');
Route::post('clock-in-out', [AttendanceEmployeeController::class, 'clockStore'])->name('clock_store')->middleware('auth');
Route::resource('dayoff', DayoffController::class)->middleware('auth');
Route::resource('company-holiday', CompanyHolidayController::class)->middleware('auth');



//Employee Request
Route::get('employee-request', [EmployeeController::class, 'employeeRequest'])
        ->name('employee.request')
        ->middleware('auth');
Route::get('employee-request/{id}', [EmployeeController::class, 'dataRequest'])
        ->name('employee.request.data')
        ->middleware('auth');
Route::post('employee-request/approve', [EmployeeController::class, 'approveRequest'])
        ->name('employee.request.approve')
        ->middleware('auth');
Route::post('employee-request/reject/{id}', [EmployeeController::class, 'rejectRequest'])
        ->name('employee.request.reject')
        ->middleware('auth');
        
        
/*Route::get('/clear', function() {

   Artisan::call('cache:clear');
   Artisan::call('config:clear');
   Artisan::call('config:cache');
   Artisan::call('view:clear');

   return "Cleared!";

});*/