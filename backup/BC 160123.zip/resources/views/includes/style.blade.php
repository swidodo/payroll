
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="{{url('public/assets/css/bootstrap.min.css')}}">

		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="{{url('public/assets/plugins/fontawesome/css/fontawesome.min.css')}}">
    	<link rel="stylesheet" href="{{url('public/assets/plugins/fontawesome/css/all.min.css')}}">

		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="{{url('public/assets/css/line-awesome.min.css')}}">
		<link rel="stylesheet" href="{{url('public/assets/css/material.css')}}">

		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="{{url('public/assets/css/font-awesome.min.css')}}">

		<!-- Lineawesome CSS -->
        <link rel="stylesheet" href="{{url('public/assets/css/line-awesome.min.css')}}">

		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="{{url('public/assets/css/font-awesome.min.css')}}">


