<!-- jQuery -->
<script src="{{url('public/assets/js/jquery-3.6.0.min.js')}}"></script>

<!-- Bootstrap Core JS -->
<script src="{{url('public/assets/js/bootstrap.bundle.min.js')}}"></script>


 <!-- Theme Settings JS -->
<script src="{{url('public/assets/js/layout.js')}}"></script>
<script src="{{url('public/assets/js/theme-settings.js')}}"></script>
<script src="{{url('public/assets/js/greedynav.js')}}"></script>

