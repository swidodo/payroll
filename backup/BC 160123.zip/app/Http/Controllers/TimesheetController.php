<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Timesheet;
use App\Models\Utility;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class TimesheetController extends Controller
{
    public function index()
    {
        if (Auth::user()->can('manage timesheet')) {
            if (Auth::user()->type == 'employee') {
                // $emp     = Employee::where('user_id', '=', Auth::user()->id)->first();
                // $travels = Travel::where('created_by', '=', Auth::user()->creatorId())->where('employee_id', '=', $emp->id)->get();
                $employee     = Employee::where('created_by', '=', Auth::user()->creatorId())->get();
            } else {
                $timesheets = Timesheet::where('created_by', '=', Auth::user()->creatorId())->get();

                $employee     = Employee::where('created_by', '=', Auth::user()->creatorId())->get();
            }

            return view('pages.contents.timesheet.index', compact('employee', 'timesheets'));
        } else {
            return redirect()->back()->with('error', 'Permission Denied.');
        }
    }

    public function store(Request $request)
    {
        if (Auth::user()->can('create timesheet')) {
            $validator = Validator::make(
                $request->all(),
                [
                    'employee_id'       => 'required',
                    'start_date'        => 'required',
                    'end_date'          => 'required',
                    'project_stage'     => 'required',
                    'task_or_project'   => 'required',
                    'activity'          => 'required',
                    'client_company'    => 'required',
                    'label_project'     => 'required',
                    'support'           => 'required',
                    'remark'            => 'required',
                ]
            );

            if ($validator->fails()) {
                return redirect()->back()->with('errors', $validator->messages());
            }

            if (Auth::user()->type == 'company') {
                if ($request->file()) {
                    $fileName = time() . '_' . $request->file('attachment')->getClientOriginalName();
                    $filePath = $request->file('attachment')->storeAs('public', $fileName);
                    $request['file_attachment'] = 'storage/' . $fileName ?? null;
                }

                $request['status'] = 'Approved';
                $request['created_by'] = Auth::user()->creatorId();

                try {
                    DB::beginTransaction();
                    $model = Timesheet::create($request->except('attachment'));
                    Utility::insertToRequest($model, Auth::user(), 'Timesheet');

                    DB::commit();
                    toast('Timesheet  successfully created.', 'success');
                } catch (Exception $e) {
                    DB::rollback();
                    toast('Terjadi Kesalahan saat Input Data.', 'error');
                    return redirect()->back();
                }
            } else {
                if ($request->file()) {
                    $fileName = time() . '_' . $request->file('attachment')->getClientOriginalName();
                    $filePath = $request->file('attachment')->storeAs('public', $fileName);
                    $request['file_attachment'] = 'storage/' . $fileName ?? null;
                }

                $request['status'] = 'Pending';
                $request['created_by'] = Auth::user()->creatorId();

                try {
                    DB::beginTransaction();
                    $model = Timesheet::create($request->except('attachment'));
                    Utility::insertToRequest($model, Auth::user(), 'Timesheet');

                    DB::commit();
                    toast('Timesheet  successfully created.', 'success');
                } catch (Exception $e) {
                    DB::rollback();
                    toast('Terjadi Kesalahan saat Input Data.', 'error');
                    return redirect()->back();
                }
            }

            return redirect()->route('timesheets.index');
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back()->with('error', 'Permission denied.');
        }
    }

    public function edit(Timesheet $timesheet)
    {
        if (Auth::user()->can('edit timesheet')) {
            // $employees = Employee::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
            if ($timesheet->created_by == Auth::user()->creatorId()) {
                return response()->json($timesheet);
            } else {
                return response()->json(['error' => 'Permission denied.'], 401);
            }
        } else {
            return response()->json(['error' => 'Permission denied.'], 401);
        }
    }

    public function show($id)
    {
        $timesheet = Timesheet::find($id);
        $fileType = null;

        if (!is_null($timesheet->attachment_reject)) {
            $fileType = Utility::getFileType($timesheet->attachment_reject);
        }

        return view('pages.contents.timesheet.detail-rejected', compact('timesheet', 'fileType'));
    }

    public function update(Request $request, Timesheet $timesheet)
    {
        if (Auth::user()->can('create timesheet')) {
            $validator = Validator::make(
                $request->all(),
                [
                    'employee_id'       => 'required',
                    'start_date'        => 'required',
                    'end_date'          => 'required',
                    'project_stage'     => 'required',
                    'task_or_project'   => 'required',
                    'activity'          => 'required',
                    'client_company'    => 'required',
                    'label_project'     => 'required',
                    'support'           => 'required',
                    'remark'            => 'required',
                ]
            );

            if ($validator->fails()) {
                return redirect()->back()->with('errors', $validator->messages());
            }

            if ($request->file('attachment')) {
                $fileName = time() . '_' . $request->file('attachment')->getClientOriginalName();
                $request->file('attachment')->storeAs('public', $fileName);
                $path = 'storage/' . $fileName;
                $request['file_attachment'] = $path ?? null;
            }
            if ($request->file('attachment_rejected')) {
                $fileNameReject = time() . '_' . $request->file('attachment_rejected')->getClientOriginalName();
                $request->file('attachment_rejected')->storeAs('public', $fileNameReject);
                $pathRejectedFileAtt = 'storage/' . $fileNameReject;
                $request['attachment_reject'] = $pathRejectedFileAtt ?? null;
            }

            $request['status']          = $request->status;
            $request['rejected_reason'] = isset($request->rejected_reason) ? $request->rejected_reason : null;
            $request['created_by'] = Auth::user()->creatorId();

            try {
                DB::beginTransaction();
                $timesheet->update($request->except('attachment'));
                DB::commit();
                toast('Timesheet  successfully updated.', 'success');
            } catch (Exception $e) {
                DB::rollback();
                toast('an error occurred while updating the data', 'error');
                return redirect()->back();
            }

            return redirect()->route('timesheets.index');
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back()->with('error', 'Permission denied.');
        }
    }

    public function destroy(Timesheet $timesheet)
    {
        if (Auth::user()->can('delete timesheet')) {
            if ($timesheet->created_by == Auth::user()->creatorId()) {
                if ($timesheet->attachment_reject != null) {
                    $fileNameAttReject = explode('/', $timesheet->attachment_reject);
                    if (Storage::exists('public/' . $fileNameAttReject[1])) {
                        Storage::delete('public/' . $fileNameAttReject[1]);
                    }
                }

                if ($timesheet->file_attachment != null) {
                    $fileNameAttFile = explode('/', $timesheet->file_attachment);
                    if (Storage::exists('public/' . $fileNameAttFile[1])) {
                        Storage::delete('public/' . $fileNameAttFile[1]);
                    }
                }



                $timesheet->delete();

                toast('Timesheet successfully deleted.', 'success');
                return redirect()->route('timesheets.index');
            } else {
                toast('Permission denied.', 'error');
                return redirect()->back()->with('error', 'Permission denied.');
            }
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back()->with('error', 'Permission denied.');
        }
    }

    public function recordTime(Request $request)
    {
        if (Auth::user()->type != 'company' || Auth::user()->type != 'client') {
            $validator = Validator::make(
                $request->all(),
                [
                    'time_now'       => 'required',
                ]
            );

            if ($validator->fails()) {
                return redirect()->back()->with('errors', $validator->messages());
            }

            $timesheet = Timesheet::where('employee_id', Auth::user()->employee->id)->where('created_by', '=', Auth::user()->creatorId())->where('start_date', '<=', date('Y-m-d'))->where('end_date', '>=', date('Y-m-d'))->first();

            if ($timesheet->start_time == null) {
                $timesheet->start_time = $request->time_now;
            } else {
                $timesheet->end_time = $request->time_now;

                $totalDuration = strtotime($timesheet->end_time) - strtotime($timesheet->start_time);
                $hours                    = floor($totalDuration / 3600);
                $mins                     = floor($totalDuration / 60 % 60);
                $secs                     = floor($totalDuration % 60);
                $duration                 = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);

                $timesheet->duration = $duration;
            }
            $timesheet->save();

            toast('Success Record Time', 'success');
            return redirect()->route('dashboard');
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back()->with('error', 'Permission denied.');
        }
    }
}
