<?php $__env->startSection('title', 'Setting BPJS Kesehatan'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Setting BPJS Kesehatan</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Setting BPJS Kesehatan</li>
                    </ul>
                </div>
                
            </div>
        </div>
        <!-- /Page Header -->


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <div class="row justify-content-center">
            <div class="col-md-8" >
            
                <form action="<?php echo e(route('setting.bpjs-tk.post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row justify-content-center">
                        <div class="col-sm-6 col-md-6 col-lg-3" >
                            <div class="form-group" >
                                <label>Type</label>
                                <select class="form-control" name="type" id="type">
                                    <?php if($bpjs_tk_val != null): ?>
                                        <?php if($bpjs_tk_val['type'] == 'Fixed'): ?>
                                            <option value="Fixed" selected>Fixed</option>
                                            <option value="Percentage">Percentage</option>

                                        <?php elseif($bpjs_tk_val['type'] == 'Percentage'): ?>
                                            <option value="Fixed">Fixed</option>
                                            <option value="Percentage" selected>Percentage</option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value="Fixed" selected>Select Type</option>
                                        <option value="Fixed" >Fixed</option>
                                        <option value="Percentage" >Percentage</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label id="label-type"><?php echo e($bpjs_tk_val != null && $bpjs_tk_val['type'] == 'Fixed' ? 'Amount' : 'Percentage %'); ?></label>
                                <input class="form-control" name="number_value" type="number" value="<?php echo e($bpjs_tk_val['value'] ?? '-'); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-9">
                            <div class="form-group">
                                <label id="label-type">Maximum Salary</label>
                                <input class="form-control" name="maximum_salary" type="number" value="<?php echo e($bpjs_tk_val['maximum_salary'] ?? '-'); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_reimburst').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */

                $('select#type').change(function(){
                    let val = $(this).val()

                    if(val == 'Fixed'){
                        $('#label-type').html('Amount')
                    }else{
                        $('#label-type').html('Percentage %')

                    }

                })

                
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/payroll/bpjs-tk/index.blade.php ENDPATH**/ ?>