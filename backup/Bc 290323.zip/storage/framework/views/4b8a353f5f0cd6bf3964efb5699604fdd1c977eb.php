<?php $__env->startSection('title', 'Setting Level Approval'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Setting Level Approval</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Setting Level Approval</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /Page Header -->

        <div class="row justify-content-center">
            <div class="col-md-8" >
            
                <form action="<?php echo e(route('level-approvals.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="row justify-content-center">
                        <div class="col-md-6" >
                            <div class="form-group" >
                                <label>Tier 1</label>
                                <select name="level[]" id="level1" class="form-control select" required>
                                    <option value="0" >Select Tier</option>
                                    <option value="company_<?php echo e(Auth::user()->creatorId()); ?>">This Company</option>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="employee_<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-6" >
                            <div class="form-group" >
                                <label>Tier 2</label>
                                <select name="level[]" id="level2" class="form-control select">
                                    <option value="0" >Select Tier</option>
                                    <option value="company_<?php echo e(Auth::user()->creatorId()); ?>">This Company</option>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="employee_<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-6" >
                            <div class="form-group" >
                                <label>Tier 3</label>
                                <select name="level[]" id="level3" class="form-control select">
                                    <option value="0" >Select Tier</option>
                                    <option value="company_<?php echo e(Auth::user()->creatorId()); ?>">This Company</option>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="employee_<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <script>
        const tiers = JSON.parse('<?php echo json_encode($tiers); ?>')
        $.each(tiers, function (indexInArray, valueOfElement) { 
             console.log(valueOfElement);
             console.log($('#level' + valueOfElement.level + ' option[value=employee_'+ valueOfElement.employee_id +']'));
            //  console.log($('#level' + valueOfElement.level + 'option[value=employee_' + valueOfElement.employee_id +']'));
             if (valueOfElement.employee_id == null) {
                $('#level'+ valueOfElement.level +' option[value=company_' + valueOfElement.company_id +']').attr('selected','selected');
                // $('#level'+ valueOfElement.level).val(valueOfElement.company_id ? valueOfElement.company_id : 0).trigger('change');
             }else{
                $('#level' + valueOfElement.level + ' option[value=employee_'+ valueOfElement.employee_id +']').attr('selected','selected');
                // $('#level'+ valueOfElement.level).val(valueOfElement.employee_id ? valueOfElement.employee_id : 0).trigger('change');
             }
        }); 
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/set-level-approval/index.blade.php ENDPATH**/ ?>