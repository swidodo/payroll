<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <nav class="greedys sidebar-horizantal">
                <ul class="list-inline-item list-unstyled links">
                    <li class="menu-title">
                        <span>Main</span>
                    </li>
                    <li class="submenu">
                        <a href="<?php echo e(route('dashboard')); ?>"><i class="la la-dashboard <?php echo e((request()->routeIs('/')) ? 'active' : ''); ?>"></i> <span> Dashboard</span>
                            
                       </a>
                        
                    </li>
                    
                </ul>
            </nav>
            <ul class="sidebar-vertical">
                
                <li class=" <?php echo e((request()->routeIs('dashboard')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>"><i class="la la-dashboard"></i> <span> Dashboard</span>
                        
                   </a>
                   
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage employee', 'view employee', 'edit employee', 'delete employee', 'manage employee profile', 'show employee profile'])): ?>
                    <li class=" <?php echo e((request()->routeIs('employees*')) ? 'active' : ''); ?>">
                        <a class=" <?php echo e((request()->routeIs('employees*')) ? 'active' : ''); ?>" href="<?php echo e(route('employees.index')); ?>"><i class="la la-users"></i> <span>Employees</span>
                        </a>
                    </li>
                <?php endif; ?>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage on duty', 'create on duty', 'view history leave', 'manage leave', 'create leave', 'manage overtime', 'create overtime', 'manage request shift schedule', 'create request shift schedule', 'manage attendance', 'create attendance', 'manage timesheet', 'create timesheet', 'show shift schedule', 'manage dayoff', 'create dayoff',  'show employee request', 'manage company holiday', 'create company holiday'])): ?>
                    <li class="submenu">
                        <a href="#"><i class="la la-clock"></i> <span> Time Management</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage leave', 'create leave', 'edit leave', 'delete leave'])): ?>
                                <li class="<?php echo e((request()->routeIs('leaves*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('leaves*')) ? 'active' : ''); ?>" href="<?php echo e(route('leaves.index')); ?>">Leave</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view history leave'])): ?>
                                <li class="<?php echo e((request()->routeIs('history-leave*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('history-leave*')) ? 'active' : ''); ?>" href="<?php echo e(route('history-leave.index')); ?>">Histroy Leave</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage overtime', 'create overtime', 'edit overtime', 'delete overtime'])): ?>
                                <li class="<?php echo e((request()->routeIs('overtimes*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('overtimes*')) ? 'active' : ''); ?>" href="<?php echo e(route('overtimes.index')); ?>">Overtime</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage request shift schedule', 'create request shift schedule', 'edit request shift schedule', 'delete request shift schedule'])): ?>
                                <li class="<?php echo e((request()->routeIs('request-shift-schedule*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('request-shift-schedule*')) ? 'active' : ''); ?>" href="<?php echo e(route('request-shift-schedule.index')); ?>">Request Shift Schedule</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['show shift schedule'])): ?>
                                <li class="<?php echo e((request()->routeIs('shift-schedule*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('shift-schedule*')) ? 'active' : ''); ?>" href="<?php echo e(route('shift-schedule.index')); ?>">Shift Schedule</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage timesheet', 'create timesheet', 'edit timesheet', 'delete timesheet'])): ?>
                                <li class="<?php echo e((request()->routeIs('timesheets*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('timesheets*')) ? 'active' : ''); ?>" href="<?php echo e(route('timesheets.index')); ?>">Timesheet</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['show employee request'])): ?>
                                <li class=" <?php echo e((request()->routeIs('employee.request')) ? 'active' : ''); ?>">
                                    <a class="<?php echo e((request()->routeIs('employee.request*')) ? 'active' : ''); ?>" href="<?php echo e(route('employee.request')); ?>"> Employee Request
                                </a>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage on duty', 'create on duty', 'edit on duty', 'delete on duty'])): ?>
                                <li class="<?php echo e((request()->routeIs('travels*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('travels*')) ? 'active' : ''); ?>" href="<?php echo e(route('travels.index')); ?>">On Duty</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage dayoff', 'create dayoff'])): ?>
                                <li class="<?php echo e((request()->routeIs('dayoff*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('dayoff*')) ? 'active' : ''); ?>" href="<?php echo e(route('dayoff.index')); ?>">Dayoff</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage company holiday', 'create company holiday'])): ?>
                                <li class="<?php echo e((request()->routeIs('company-holiday*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('company-holiday*')) ? 'active' : ''); ?>" href="<?php echo e(route('company-holiday.index')); ?>">Company Holiday</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage attendance', 'create attendance', 'edit attendance', 'delete attendance'])): ?>
                                <li class="submenu ">
                                    <a style="padding: 9px 10px 9px 44px" href="#"> <span> Attendance</span> <span class="menu-arrow"></span></a>
                                    <ul style="display: none;">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage attendance'])): ?>
                                            <li class="<?php echo e((request()->routeIs('attendance*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('attendance*')) ? 'active' : ''); ?>" href="<?php echo e(route('attendance.index')); ?>">Attendance List</a></li>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['create attendance'])): ?>
                                            <li class="<?php echo e((request()->routeIs('bulk-attendance*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('bulk-attendance*')) ? 'active' : ''); ?>" href="<?php echo e(route('bulk-attendance.index')); ?>">Bulk Attendance</a></li>
                                        <?php endif; ?>
                                    </ul>
                                </li>
                            <?php endif; ?>

                           
                        </ul>
                    </li>
                <?php endif; ?>



                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage performance review', 'create performance review', 'edit performance review', 'delete performance review', 'manage project', 'create project'])): ?>
                    <li class="submenu">
                        <a href="#"><i class="la la-cube"></i> <span> HR Management</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage performance review', 'create performance review', 'edit performance review', 'delete performance review'])): ?>
                                <li class="submenu <?php echo e((request()->routeIs('performance-review*')) ? 'active' : ''); ?>" >
                                    <a style="padding: 9px 10px 9px 50px" href="#"> <span> Performance Setup</span> <span class="menu-arrow"></span></a>
                                    <ul style="display: none;">

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage performance review', 'create performance review', 'edit performance review', 'delete performance review'])): ?>
                                            <li class="<?php echo e((request()->routeIs('performance-review*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('performance-review*')) ? 'active' : ''); ?>" href="<?php echo e(route('performance-review.index')); ?>">Performance Review</a></li>
                                        <?php endif; ?>
                                        
                                    </ul>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage project', 'create project'])): ?>
                                <li class=" <?php echo e((request()->routeIs('projects*')) ? 'active' : ''); ?>">
                                    <a class=" <?php echo e((request()->routeIs('projects*')) ? 'active' : ''); ?>" href="<?php echo e(route('projects.index')); ?>">Projects
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage payroll', 'create payroll', 'manage denda', 'create denda', 'manage payslip', 'generate payslip'])): ?>
                    <li class="submenu">
                        <a href="#"><i class="la la-book"></i> <span> Payroll</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage payroll', 'create payroll'])): ?>
                                <li class="<?php echo e((request()->routeIs('payroll*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('payroll*')) ? 'active' : ''); ?>" href="<?php echo e(route('payroll.index')); ?>">List Payroll</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage payslip', 'generate payslip'])): ?>
                                <li class="<?php echo e((request()->routeIs('payslips*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('payslips*')) ? 'active' : ''); ?>" href="<?php echo e(route('payslips.index')); ?>">Payslip</a></li>
                            <?php endif; ?>

                            
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage reimburst', 'create reimburst', 'manage cash advance', 'create cash advance', 'manage loan', 'create loan', 'manage allowance', 'create allowance'])): ?>
                    <li class="submenu">
                        <a href="#"><i class="la la-usd"></i> <span> Finance</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage reimburst', 'create reimburst'])): ?>
                                <li class="<?php echo e((request()->routeIs('reimburst*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('reimburst*')) ? 'active' : ''); ?>" href="<?php echo e(route('reimburst.index')); ?>"> Reimburst</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage cash advance', 'create cash advance'])): ?>
                                <li class="<?php echo e((request()->routeIs('cash*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('cash*')) ? 'active' : ''); ?>" href="<?php echo e(route('cash.index')); ?>"> Cash Advance</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage loan', 'create loan'])): ?>
                                <li class="<?php echo e((request()->routeIs('loans*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('loans*')) ? 'active' : ''); ?>" href="<?php echo e(route('loans.index')); ?>"> Loan</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage allowance', 'create allowance'])): ?>
                            <li class=" <?php echo e((request()->routeIs('allowances*')) ? 'active' : ''); ?>">
                                <a class=" <?php echo e((request()->routeIs('allowances*')) ? 'active' : ''); ?>" href="<?php echo e(route('allowances.index')); ?>"> Allowance
                                </a>
                            </li>
                            <?php endif; ?>

                            
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage user', 'create user', 'manage role', 'create role', 'manage level approval', 'edit level approval', 'manage denda', 'create denda', 'edit denda', 'delete denda', 'manage bpjs kesehatan', 'create bpjs kesehatan', 'edit bpjs kesehatan', 'delete bpjs kesehatan', 'manage pph21', 'edit pph21', 'manage jht', 'create jht', 'manage jkk', 'create jkk', 'manage jkm', 'create jkm', 'manage jp', 'create jp', 'manage payslip code pin', 'manage payslip checklist attendance summary', 'manage allowance option', 'create allowance option', 'manage leave type', 'manage reimbursement option', 'manage branch', 'manage loan option', 'manage payslip type'])): ?>
                    <li class="submenu">
                        <a href="#"><i class="la la-cog"></i> <span> Setting</span> <span class="menu-arrow"></span></a>
                        <ul style="display: none;">

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage user', 'create user'])): ?>
                                <li class="<?php echo e((request()->routeIs('users*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('users*')) ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">Users</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage role', 'create role'])): ?>
                                <li class="<?php echo e((request()->routeIs('roles*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('roles*')) ? 'active' : ''); ?>" href="<?php echo e(route('roles.index')); ?>">Roles</a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage level approval', 'edit level approval'])): ?>
                                <li class="<?php echo e((request()->routeIs('level-approvals*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('level-approvals*')) ? 'active' : ''); ?>" href="<?php echo e(route('level-approvals.index')); ?>">Set Level Approval </a></li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage denda', 'create denda', 'edit denda', 'delete denda', 'manage bpjs kesehatan', 'create bpjs kesehatan', 'edit bpjs kesehatan', 'delete bpjs kesehatan', 'manage pph21', 'edit pph21', 'manage jht', 'create jht', 'manage jkk', 'create jkk', 'manage jkm', 'create jkm', 'manage jp', 'create jp', 'manage payslip code pin', 'manage payslip checklist attendance summary'])): ?>
                                <li class="submenu" >
                                    <a style="padding: 9px 10px 9px 50px" href="#"> <span> Setting Payroll</span> <span class="menu-arrow"></span></a>
                                    <ul style="display: none;">

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage payslip checklist attendance summary', 'edit payslip checklist attendance summary'])): ?>
                                            <li class="<?php echo e((request()->routeIs('checklist-attendance-summary*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('checklist-attendance-summary*')) ? 'active' : ''); ?>" href="<?php echo e(route('checklist-attendance-summary.index')); ?>">Checklist Attendance Summary</a></li>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage payslip code pin', 'edit payslip code pin'])): ?>
                                            <li class="<?php echo e((request()->routeIs('payslip-code-pin*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('payslip-code-pin*')) ? 'active' : ''); ?>" href="<?php echo e(route('payslip-code-pin.index')); ?>">Payslip Code PIN</a></li>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage denda', 'create denda', 'edit denda', 'delete denda'])): ?>
                                            <li class="<?php echo e((request()->routeIs('denda*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('denda*')) ? 'active' : ''); ?>" href="<?php echo e(route('denda.index')); ?>">Deduction</a></li>
                                        <?php endif; ?>

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage bpjs kesehatan', 'create bpjs kesehatan', 'edit bpjs kesehatan', 'delete bpjs kesehatan'])): ?>
                                            <li class="<?php echo e((request()->routeIs('setting.bpjs-tk*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('setting.bpjs-tk*')) ? 'active' : ''); ?>" href="<?php echo e(route('setting.bpjs-tk.index')); ?>">BPJS Kesehatan</a></li>
                                        <?php endif; ?>

                                        

                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage jht', 'create jht', 'manage jkk', 'create jkk', 'manage jkm', 'create jkm', 'manage jp', 'create jp'])): ?>
                                        <li class="submenu" >
                                            <a style="padding: 9px 10px 9px 44px" href="#"> <span> BPJS TK </span> <span class="menu-arrow"></span></a>
                                            <ul style="display: none;">

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage jht', 'create jht', 'manage jkk', 'create jkk', 'manage jkm', 'create jkm', 'manage jp', 'create jp'])): ?>
                                                    <li class=" <?php echo e((request()->routeIs('set-bpjstk*')) ? 'active' : ''); ?>">
                                                        <a class=" <?php echo e((request()->routeIs('set-bpjstk*')) ? 'active' : ''); ?>" href="<?php echo e(route('set-bpjstk.index')); ?>"> Set BPJS TK
                                                        </a>
                                                    </li>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage jht', 'create jht', 'edit jht', 'delete jht'])): ?>
                                                    <li class="<?php echo e((request()->routeIs('setting.jht*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('setting.jht*')) ? 'active' : ''); ?>" href="<?php echo e(route('setting.jht.index')); ?>">Jaminan Hari Tua (JHT)</a></li>
                                                <?php endif; ?>
    
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage jkk', 'create jkk', 'edit jkk', 'delete jkk'])): ?>
                                                <li class="<?php echo e((request()->routeIs('setting.jkk*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('setting.jkk*')) ? 'active' : ''); ?>" href="<?php echo e(route('setting.jkk.index')); ?>">Jaminan Kecelakaan Kerja (JKK)</a></li>
                                            <?php endif; ?>
    
    
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage jkm', 'create jkm', 'edit jkm', 'delete jkm'])): ?>
                                                <li class="<?php echo e((request()->routeIs('setting.jkm*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('setting.jkm*')) ? 'active' : ''); ?>" href="<?php echo e(route('setting.jkm.index')); ?>">Jaminan Kematian (JKM)</a></li>
                                            <?php endif; ?>
    
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage jp', 'create jp', 'edit jp', 'delete jp'])): ?>
                                                <li class="<?php echo e((request()->routeIs('setting.jp*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('setting.jp*')) ? 'active' : ''); ?>" href="<?php echo e(route('setting.jp.index')); ?>">Jaminan Pensiun (JP)</a></li>
                                            <?php endif; ?>

                                            </ul>
                                        </li>
                                        <?php endif; ?>

                                        <li class="submenu" >
                                            <a style="padding: 9px 10px 9px 44px" href="#"> <span> PPH21 </span> <span class="menu-arrow"></span></a>
                                            <ul style="display: none;">

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage set ptkp', 'create set ptkp', 'edit set ptkp', 'delete set ptkp'])): ?>
                                                    <li class=" <?php echo e((request()->routeIs('set-ptkp*')) ? 'active' : ''); ?>">
                                                        <a class=" <?php echo e((request()->routeIs('set-ptkp*')) ? 'active' : ''); ?>" href="<?php echo e(route('set-ptkp.index')); ?>"> Set PTKP
                                                        </a>
                                                    </li>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage ptkp', 'edit ptkp'])): ?>
                                                    <li class=" <?php echo e((request()->routeIs('setting.ptkp*')) ? 'active' : ''); ?>">
                                                        <a class=" <?php echo e((request()->routeIs('setting.ptkp*')) ? 'active' : ''); ?>" href="<?php echo e(route('setting.ptkp.index')); ?>"> PTKP
                                                        </a>
                                                    </li>
                                                <?php endif; ?>

                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage pph21', 'create pph21', 'edit pph21', 'delete pph21'])): ?>
                                                    <li class="<?php echo e((request()->routeIs('setting.pph21*')) ? 'active' : ''); ?>"><a class="<?php echo e((request()->routeIs('setting.pph21*')) ? 'active' : ''); ?>" href="<?php echo e(route('setting.pph21.index')); ?>">PPH21</a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </li>

                                        

                                    </ul>
                                </li>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage allowance option', 'create allowance option', 'manage leave type', 'manage reimbursement option', 'manage branch', 'manage loan option', 'manage payslip type'])): ?>
                                <li class="submenu" >
                                <a style="padding: 9px 10px 9px 50px" href="#"> <span> Master Data</span> <span class="menu-arrow"></span></a>
                                <ul style="display: none;padding: px 10px 9px 50px">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage branch', 'create branch', 'edit branch', 'delete branch'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('branches*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('branches*')) ? 'active' : ''); ?>" href="<?php echo e(route('branches.index')); ?>"></i> <span> Branch</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage shift type', 'create shift type', 'edit shift type', 'delete shift type'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('shift-type*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('shift-type*')) ? 'active' : ''); ?>" href="<?php echo e(route('shift-type.index')); ?>"></i> <span> Shift Type</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage allowance option', 'create allowance option', 'edit allowance option', 'delete allowance option'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('allowance-option*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('allowance-option*')) ? 'active' : ''); ?>" href="<?php echo e(route('allowance-option.index')); ?>"></i> <span> Allowance Option</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage leave type', 'create leave type', 'edit leave type', 'delete leave type'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('leave-type*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('leave-type*')) ? 'active' : ''); ?>" href="<?php echo e(route('leave-type.index')); ?>"></i> <span> Leave Type</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage reimbursement option', 'create reimbursement option', 'edit reimbursement option', 'delete reimbursement option'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('reimbursement-option*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('reimbursement-option*')) ? 'active' : ''); ?>" href="<?php echo e(route('reimbursement-option.index')); ?>"></i> <span> Reimbursement Option</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage loan option', 'create loan option', 'edit loan option', 'delete loan option'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('loan-option*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('loan-option*')) ? 'active' : ''); ?>" href="<?php echo e(route('loan-option.index')); ?>"></i> <span> Cash in Advance</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage payslip type', 'create payslip type', 'edit payslip type', 'delete payslip type'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('payslip-type*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('payslip-type*')) ? 'active' : ''); ?>" href="<?php echo e(route('payslip-type.index')); ?>"></i> <span> Payslip Type</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage overtime type', 'create overtime type', 'edit overtime type', 'delete overtime type'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('overtime-type*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('overtime-type*')) ? 'active' : ''); ?>" href="<?php echo e(route('overtime-type.index')); ?>"></i> <span> Overtime Type</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['manage day type', 'create day type', 'edit day type', 'delete day type'])): ?>
                                        <li class=" <?php echo e((request()->routeIs('day-type*')) ? 'active' : ''); ?>">
                                            <a  class="<?php echo e((request()->routeIs('day-type*')) ? 'active' : ''); ?>" href="<?php echo e(route('day-type.index')); ?>"></i> <span> Day Type</span>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/pehadirm/public_html/resources/views/includes/sidebar.blade.php ENDPATH**/ ?>