<?php $__env->startSection('title', 'Branches'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Manage Bulk Attendance</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('attendance.index')); ?>">Attendance</a></li>
                        <li class="breadcrumb-item active">Bulk Attendance</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /Page Header -->


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('error')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <form method="GET" action="<?php echo e(route('bulk-attendance.index')); ?>" accept-charset="UTF-8" id="bulkattendance_filter">
                            <?php echo csrf_field(); ?>
                        <div class="row justify-content-end">
                                    <div class="col-md-3">
                                        <div class="btn-box">
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="btn-box">
                                            <label for="date" class="form-label">Date</label>
                                            <input class="month-btn form-control " name="date" type="date" value="<?php echo e(isset($_GET['date'])?$_GET['date']:date('Y-m-d')); ?>" id="date">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="btn-box">
                                            <label for="branch" class="form-label">Branch</label>
                                            <select class="form-control select" required="" id="branch" name="branch">
                                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                            <div class="col-auto d-flex align-items-end pb-2">
                                <a href="#" class="btn btn-sm btn-primary" onclick="document.getElementById('bulkattendance_filter').submit(); return false;" data-bs-toggle="tooltip" title="" data-original-title="apply" data-bs-original-title="Apply">
                                    <span class="btn-inner--icon"><i class="la la-search"></i></span>
                                </a>
                            </div>
                        </div>
                    </form></div>

                </div>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-body table-border-style">
                        <h5></h5>

                        <form method="POST" action="<?php echo e(route('bulk-attendance.index')); ?>" >
                            <?php echo csrf_field(); ?>
                        <div class="table-responsive">
                            <table class="table" id="pc-dt-simple">
                                <thead>
                                <tr>
                                    <th width="10%">Employee Id</th>
                                    <th>Employee</th>
                                    <th>Branch</th>
                                    <th>
                                        <div class="form-group my-auto">
                                            <div class="custom-control ">
                                                <input class="form-check-input" type="checkbox" name="present_all"
                                                       id="present_all" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                <label class="custom-control-label" for="present_all">
                                                    Attendance</label>
                                            </div>
                                        </div>
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $attendance = $employee->present_status($employee->id, isset($_GET['date']) ? $_GET['date'] : date('Y-m-d'));
                                        ?>

                                        <tr>
                                            <td class="Id">
                                                <input type="hidden" value="<?php echo e($employee->id); ?>" name="employee_id[]">
                                                <a href="" class=" btn btn-outline-primary"><?php echo e(Auth::user()->employeeIdFormat($employee->employee_id)); ?></a>
                                            </td>
                                            <td><?php echo e($employee->name); ?></td>
                                            <td><?php echo e(!empty($employee->branch) ? $employee->branch->name : ''); ?></td>
                                            <td>
                                                <div class="row">
                                                    <div class="col-md-10 d-flex">
                                                        <div class="row">
                                                            <div class="col-md-1">
                                                                <div class="form-group">
                                                                    <div class="custom-control custom-checkbox mt-2">
                                                                        <input class="form-check-input present" type="checkbox" name="present-<?php echo e($employee->id); ?>" id="present<?php echo e($employee->id); ?>" <?php echo e(!empty($attendance) && $attendance->status == 'Present' ? 'checked' : ''); ?>>
                                                                        <label class="custom-control-label" for="present<?php echo e($employee->id); ?>"></label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-10 present_check_in <?php echo e(empty($attendance) ? 'd-none' : ''); ?>">
                                                                <div class="row">
                                                                    <label class="col-md-2 form-label mt-2">In</label>

                                                                    <div class="col-md-4">
                                                                        <input type="text" class="form-control timepickerr" name="in-<?php echo e($employee->id); ?>" value="<?php echo e(!empty($attendance) && $attendance->clock_in != '00:00:00' ? \Carbon\Carbon::parse( $attendance->clock_in)->format('H:i') : \Carbon\Carbon::parse( \App\Models\Utility::getValByName('company_start_time'))->format('H:i')); ?>">
                                                                    </div>

                                                                    <label for="inputValue" class="col-md-2 form-label mt-2">Out</label>
                                                                    <div class="col-md-4">
                                                                        <input type="text" class="form-control timepickerr" name="out-<?php echo e($employee->id); ?>" value="<?php echo e(!empty($attendance) && $attendance->clock_out != '00:00:00' ? \Carbon\Carbon::parse( $attendance->clock_out)->format('H:i')  : \Carbon\Carbon::parse( \App\Models\Utility::getValByName('company_end_time'))->format('H:i')); ?>">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="attendance-btn float-end pt-4">
                            <input type="hidden" value="<?php echo e(isset($_GET['date']) ? $_GET['date'] : date('Y-m-d')); ?>" name="date">
                            <input type="hidden" value="<?php echo e(isset($_GET['branch']) ? $_GET['branch'] : '1'); ?>" name="branch">
                            
                            <input class="btn btn-primary" type="submit" value="Update">
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

      <!-- Jquery timepicker -->
      <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.timepicker.min.css')); ?>">

      <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

     <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

   <!-- timepicker JS -->
   <script src="<?php echo e(asset('assets/js/jquery.timepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_user').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */

                $('input[class*="timepickerr"]').each(function(){
                        $(this).timepicker({
                            timeFormat: 'HH:mm',
                            // minTime: '05:00'
                        });
                    })

                $('#present_all').click(function (event) {

                if (this.checked) {
                    $('.present').each(function () {
                        this.checked = true;
                    });

                    $('.present_check_in').removeClass('d-none');
                    $('.present_check_in').addClass('d-block');

                } else {
                    $('.present').each(function () {
                        this.checked = false;
                    });
                    $('.present_check_in').removeClass('d-block');
                    $('.present_check_in').addClass('d-none');

                }
                });

                $('.present').click(function (event) {


                var div = $(this).parent().parent().parent().parent().find('.present_check_in');
                if (this.checked) {
                    div.removeClass('d-none');
                    div.addClass('d-block');
                } else {
                    div.removeClass('d-block');
                    div.addClass('d-none');
                }

                });
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/attendance/bulk.blade.php ENDPATH**/ ?>