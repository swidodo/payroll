<!-- Add User Modal -->
<div id="add_role" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Create New Role</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('roles.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Role Name <span class="text-danger">*</span></label>
                                <input class="form-control" type="text" placeholder="Enter Role Name" name="name">

                                <?php if($errors->has('name')): ?>
                                <div class="text-danger" role="alert">
                                    <small><strong><?php echo e($errors->get('name')[0]); ?></strong></small>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-staff-tab" data-bs-toggle="pill" data-bs-target="#pills-staff" href="#staff" role="tab" aria-controls="pills-staff" aria-selected="true">Staff</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-hrmpermission-tab" data-bs-toggle="pill" data-bs-target="#pills-hrmpermission" href="#pills-hrmpermission" role="tab" aria-controls="pills-hrmpermission" aria-selected="false">HRM</a>
                                </li>
                                
                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-staff" role="tabpanel" aria-labelledby="pills-staff-tab">
                                    <?php
                                        // $modules=['user','role','client','product & service','constant unit','constant tax','constant category','company settings'];
                                        $modules=['user','role', 'employee request'];
                                        //    if(Auth::user()->type == 'company'){
                                        //        $modules[] = 'permission';
                                        //    }
                                    ?>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php if(!empty($permissions)): ?>
                                                <h6 class="my-3">Assign General Permission to Roles</h6>
                                                <table class="table table-striped mb-0" id="dataTable-1">
                                                    <thead>
                                                    <tr>
                                                        <th>
                                                            <input type="checkbox" class="form-check-input" name="staff_checkall_edit"  id="staff_checkall_edit" >
                                                        </th>
                                                        <th>Module </th>
                                                        <th>Permissions </th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>

                                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><input type="checkbox" class="form-check-input ischeck staff_checkall"  data-id="<?php echo e(str_replace(' ', '', str_replace('&', '', $module))); ?>" ></td>
                                                            <td><label class="ischeck staff_checkall" data-id="<?php echo e(str_replace(' ', '', str_replace('&', '', $module))); ?>"><?php echo e(ucfirst($module)); ?></label></td>
                                                            <td>
                                                                <div class="row ">
                                                                    <?php if(in_array('view '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('view '.$module,$permissions)): ?>
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                        View
                                                                                    </label>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('add '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('add '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Add
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('move '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('move '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Move
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('manage '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('manage '.$module,$permissions)): ?>

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Manage
                                                                                </label>
                                                                            </div>

                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('create '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('create '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                        Create
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    <?php if(in_array('edit '.$module,(array) $permissions)): ?>
                                                                    <?php if($key = array_search('edit '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                        Edit
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    <?php if(in_array('delete '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('delete '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                        Delete
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    <?php if(in_array('show '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('show '.$module,$permissions)): ?>

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheck staff_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                        Show
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                 
                                
                                <div class="tab-pane fade" id="pills-hrmpermission" role="tabpanel" aria-labelledby="pills-hrmpermission-tab">
                                    <?php
                                        $modules=['attendance', 'leave', 'overtime', 'request shift schedule', 'shift schedule', 'reimbursement option', 'branch', 'leave type', 'performance review', 'loan option', 'denda', 'bpjs kesehatan', 'allowance option', 'payslip', 'payslip type', 'day type', 'overtime type', 'shift type', 'on duty', 'timesheet', 'payroll'];
                                        // $modules=['hrm dashboard','employee','employee profile','department','designation','branch','document type','document','payslip type','allowance','commission','allowance option','loan option','deduction option','loan','saturation deduction','other payment','overtime','set salary','pay slip','company policy','appraisal','goal tracking','goal type','indicator','event','meeting','training','trainer','training type','award','award type','resignation','travel','promotion','complaint','warning','termination','termination type','job application','job application note','job onBoard','job category','job','job stage','custom question','interview schedule','estimation','holiday','transfer','announcement','leave','leave type','attendance'];
                                    ?>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php if(!empty($permissions)): ?>
                                                <h6 class="my-3"><?php echo e('Assign HRM related Permission to Roles'); ?>

                                                </h6>

                                                <table class="table table-striped mb-0" id="dataTable-1">
                                                    <thead>
                                                    <tr>
                                                        <th>
                                                            <input type="checkbox" class="form-check-input align-middle custom_align_middle" name="hrm_checkall"  id="hrm_checkall" >
                                                        </th>
                                                        <th><?php echo e('Module'); ?> </th>
                                                        <th><?php echo e('Permissions'); ?> </th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><input type="checkbox" class="form-check-input align-middle ischeck hrm_checkall"  data-id="<?php echo e(str_replace(' ', '', $module)); ?>" ></td>
                                                            <td><label class="ischeck hrm_checkall" data-id="<?php echo e(str_replace(' ', '', $module)); ?>"><?php echo e(ucfirst($module)); ?></label></td>
                                                            <td>
                                                                <div class="row ">

                                                                    <?php if(in_array('view '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('view '.$module,$permissions)): ?>
                                                                            

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    View
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('add '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('add '.$module,$permissions)): ?>
                                                                            

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    add
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('manage '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('manage '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Manage
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('generate '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('generate '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Generate
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('create '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('create '.$module,$permissions)): ?>

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Create
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    <?php if(in_array('edit '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('edit '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Edit
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    <?php if(in_array('delete '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('delete '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Delete
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    <?php if(in_array('show '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('show '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    View
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Add User Modal -->

<!-- Edit User Modal -->
<div id="edit_role" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Role</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="edit-form-role" action="" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Role Name <span class="text-danger">*</span></label>
                                <input class="form-control" type="text" placeholder="Enter Role Name" name="name" id="role-name">

                                <?php if($errors->has('name')): ?>
                                <div class="text-danger" role="alert">
                                    <small><strong><?php echo e($errors->get('name')[0]); ?></strong></small>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="pills-staffs-tab" data-bs-toggle="pill" data-bs-target="#pills-staffs" href="#staff" role="tab" aria-controls="pills-staffs" aria-selected="true">Staff</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" id="pills-hrmpermission-tab" data-bs-toggle="pill" data-bs-target="#pills-hrmpermissions" href="#pills-hrmpermission" role="tab" aria-controls="pills-hrmpermission" aria-selected="false">HRM</a>
                                </li>
                                
                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-staffs" role="tabpanel" aria-labelledby="pills-staffs-tab">
                                    <?php
                                        // $modules=['user','role','client','product & service','constant unit','constant tax','constant category','company settings'];
                                        $modules=['user','role', 'employee request'];
                                        //    if(Auth::user()->type == 'company'){
                                        //        $modules[] = 'permission';
                                        //    }
                                    ?>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php if(!empty($permissions)): ?>
                                                <h6 class="my-3">Assign General Permission to Roles</h6>
                                                <table class="table table-striped mb-0" id="dataTable-1">
                                                    <thead>
                                                    <tr>
                                                        <th>
                                                            <input type="checkbox" class="form-check-input" name="staff_checkall_edit"  id="staff_checkall_edit" >
                                                        </th>
                                                        <th>Module </th>
                                                        <th>Permissions </th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>

                                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><input type="checkbox" class="form-check-input ischeck staff_checkall_edit"  data-id="<?php echo e(str_replace(' ', '', str_replace('&', '', $module))); ?>" ></td>
                                                            <td><label class="ischeck staff_checkall_edit" data-id="<?php echo e(str_replace(' ', '', str_replace('&', '', $module))); ?>"><?php echo e(ucfirst($module)); ?></label></td>
                                                            <td>
                                                                <div class="row ">
                                                                    <?php if(in_array('view '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('view '.$module,$permissions)): ?>
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                        View
                                                                                    </label>
                                                                                </div>
                                                                            <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('add '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('add '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    Add
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('move '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('move '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    Move
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('manage '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('manage '.$module,$permissions)): ?>

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    Manage
                                                                                </label>
                                                                            </div>

                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('create '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('create '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                        Create
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    <?php if(in_array('edit '.$module,(array) $permissions)): ?>
                                                                    <?php if($key = array_search('edit '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                        Edit
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    <?php if(in_array('delete '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('delete '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                        Delete
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    <?php if(in_array('show '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('show '.$module,$permissions)): ?>

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                                    <input class="form-check-input isscheckedit staff_checkall_edit isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                    <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                        Show
                                                                                    </label>
                                                                                </div>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                 
                                
                                <div class="tab-pane fade" id="pills-hrmpermissions" role="tabpanel" aria-labelledby="pills-hrmpermissions-tab">
                                    <?php
                                        $modules=['attendance', 'leave', 'overtime', 'request shift schedule', 'shift schedule', 'reimbursement option', 'branch', 'leave type', 'performance review', 'loan option', 'denda', 'bpjs kesehatan', 'allowance option', 'payslip', 'payslip type', 'day type', 'overtime type', 'shift type', 'on duty', 'timesheet', 'payroll'];
                                        // $modules=['hrm dashboard','employee','employee profile','department','designation','branch','document type','document','payslip type','allowance','commission','allowance option','loan option','deduction option','loan','saturation deduction','other payment','overtime','set salary','pay slip','company policy','appraisal','goal tracking','goal type','indicator','event','meeting','training','trainer','training type','award','award type','resignation','travel','promotion','complaint','warning','termination','termination type','job application','job application note','job onBoard','job category','job','job stage','custom question','interview schedule','estimation','holiday','transfer','announcement','leave','leave type','attendance'];
                                    ?>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <?php if(!empty($permissions)): ?>
                                                <h6 class="my-3"><?php echo e('Assign HRM related Permission to Roles'); ?>

                                                </h6>

                                                <table class="table table-striped mb-0" id="dataTable-1">
                                                    <thead>
                                                    <tr>
                                                        <th>
                                                            <input type="checkbox" class="form-check-input align-middle custom_align_middle" name="hrm_checkall"  id="hrm_checkall" >
                                                        </th>
                                                        <th><?php echo e('Module'); ?> </th>
                                                        <th><?php echo e('Permissions'); ?> </th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><input type="checkbox" class="form-check-input align-middle ischeck hrm_checkall"  data-id="<?php echo e(str_replace(' ', '', $module)); ?>" ></td>
                                                            <td><label class="ischeck hrm_checkall" data-id="<?php echo e(str_replace(' ', '', $module)); ?>"><?php echo e(ucfirst($module)); ?></label></td>
                                                            <td>
                                                                <div class="row ">

                                                                    <?php if(in_array('view '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('view '.$module,$permissions)): ?>
                                                                            

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit hrm_checkall isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    View
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('add '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('add '.$module,$permissions)): ?>
                                                                            

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit hrm_checkall isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    add
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('manage '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('manage '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit hrm_checkall isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    Manage
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('generate '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('generate '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheck hrm_checkall isscheck_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>" >
                                                                                    Generate
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>

                                                                    <?php if(in_array('create '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('create '.$module,$permissions)): ?>

                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit hrm_checkall isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    Create
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    <?php if(in_array('edit '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('edit '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit hrm_checkall isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    Edit
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    <?php if(in_array('delete '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('delete '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit hrm_checkall isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    Delete
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                    <?php if(in_array('show '.$module,(array) $permissions)): ?>
                                                                        <?php if($key = array_search('show '.$module,$permissions)): ?>
                                                                            <div class="col-md-3 custom-control custom-checkbox">
                                                                                <input class="form-check-input isscheckedit hrm_checkall isscheckedit_<?php echo e(str_replace(' ', '',  str_replace('&', '', $module))); ?>" type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" id="permission<?php echo e($key); ?>edit">

                                                                                <label class="custom-control-label" for="permission<?php echo e($key); ?>edit" >
                                                                                    View
                                                                                </label>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    <?php endif; ?>


                                                                    
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Edit User Modal -->

 <!-- Delete User Modal -->
 <div class="modal custom-modal fade" id="delete_role" role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-header">
                    <h3>Delete Role</h3>
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-btn delete-action">
                    <div class="row">
                        <div class="col-6">
                            <form action="" id="role-delete-form" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary continue-btn">Delete</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-6">
                            <a href="javascript:void(0);" data-bs-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Delete User Modal -->
<?php /**PATH /home/pehadirm/public_html/resources/views/includes/modal/roles-modal.blade.php ENDPATH**/ ?>