<?php $__env->startSection('title', 'Create Denda'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Create Denda</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active"><a href="<?php echo e(route('denda.index')); ?>">Denda</a></li>
                        <li class="breadcrumb-item active">Create</li>
                    </ul>
                </div>

            </div>
        </div>
        <!-- /Page Header -->

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header p-3">
                        <div class="d-flex align-items-center">
                            <h5 class="card-title mb-0" id="title">Create Denda</h5>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('denda.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-12">

                                    <div class="row mt-3">
                                        <div class="col-md-12">
                                            <div class="card mb-0">
                                                <div class="card-body">
                                                    <div id="container-denda">

                                                    </div>
                                                    <a href="#" id="add-denda"> + Add New</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="submit-section">
                                <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

       <!-- Jquery timepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.timepicker.min.css')); ?>">


    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- timepicker JS -->
    <script src="<?php echo e(asset('assets/js/jquery.timepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_user').modal('show')
        });
    </script>
    <?php endif; ?>
    <script>
            $(document).ready(function () {
                /* When click show user */

                $('#add-denda').click(function(e){
                    e.preventDefault();

                    let dendaNo
                    if ($('span[id*="counterBreak"]').last().html() > 0) {
                        dendaNo = parseInt($('span[id*="counterBreak"]').last().html()) +1
                    }else{
                        dendaNo = 1
                    }

                    let content = `<div class="card flex-fill" id="card-denda-${dendaNo}">
                                                            <div class="card-header d-flex">
                                                                <div class="d-flex align-items-center me-auto">
                                                                    <h5 class="card-title mb-0" id="title">Denda <span id="counterBreak${dendaNo}">${dendaNo}</span></h5>
                                                                </div>
                                                                <a href="#" class="btn btn-danger" data-id="${dendaNo}" id="delete-break"><i class="la la-trash"></i></a>
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="wrapper-form ">
                                                                    <div class="row"  id="form-edit-education">

                                                                        <div class="form-group col-md-6">
                                                                            <label for="phone" class="form-label">Day Type</label><span class="text-danger pl-1"> *</span>
                                                                            <select required class=" select" id="" name="denda[${dendaNo}][day_type_id]">
                                                                                <option value="0">Select Shift</option>
                                                                                <?php $__currentLoopData = $dayTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>

                                                                        <div class="form-group col-md-6">
                                                                            <label for="name" class="form-label">Time</label><span class="text-danger pl-1"> *</span>
                                                                            <input required class="form-control" type="text" value="" name="denda[${dendaNo}][time]">
                                                                        </div>

                                                                        <div class="form-group col-md-6">
                                                                            <label for="name" class="form-label">Amount</label><span class="text-danger pl-1"> *</span>
                                                                                <input required class="form-control" type="text" value="" name="denda[${dendaNo}][amount]">
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>`

                    $('#container-denda').append(content)
                    $('input[name*="time"]').each(function( index ) {
                        $(this).timepicker({
                            timeFormat: 'HH:mm',
                            // minTime: '05:00'
                        });
                    })

                    $('select[name*="day_type_id"]').each(function( index ) {
                        $(this).select2({
                            width: '100%',
                            tags: true,
                        });
                    })

                })


                $('body').on('click','#delete-break', function(e){
                    e.preventDefault()
                    const cardId = $(this).data('id')
                    $('#card-denda-'+ cardId).remove()
                    const lengthCounter = $('span[id*="counterBreak"]').length
                    console.log(lengthCounter);

                    for (let i = 0; i < lengthCounter; i++) {
                        // $('span[id*="counterBreak'+ i +'"]').html()
                        console.log($('span[id*="counterBreak"]').get(i).innerHTML = i+1);
                        // console.log('ini ke'+ i);
                    }



                })

            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/denda/create.blade.php ENDPATH**/ ?>