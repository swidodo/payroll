<?php $__env->startSection('title', 'Shift Type'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Manage Shift Type</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Shift Type</li>
                    </ul>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create shift type')): ?>
                    <div class="col-auto float-end ms-auto">
                        <a href="<?php echo e(route('shift-type.create')); ?>" class="btn add-btn"><i class="fa fa-plus"></i> Shift Type</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /Page Header -->


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive" style="overflow-x: visible">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>Shift Name</th>
                                <th>Time</th>
                                <?php if(Auth::user()->can('edit shift type') || Auth::user()->can('delete shift type')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $shiftTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($type->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($type->start_time)->format('H:i').' - '.Carbon\Carbon::parse($type->end_time)->format('H:i')); ?>

                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit shift type', 'delete shift type'])): ?>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>

                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit shift type')): ?>
                                                        <a  href="<?php echo e(route('shift-type.edit', $type->id)); ?>" id="edit-shift-type" class="dropdown-item" ><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete shift type')): ?>
                                                        <form action="<?php echo e(route('shift-type.destroy', $type->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="dropdown-item"><i class="fa fa-trash-o m-r-5"> </i> Delete</button>
                                                        </form>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

       <!-- Jquery timepicker -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.timepicker.min.css')); ?>">


    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- timepicker JS -->
    

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_user').modal('show')
        });
    </script>
    <?php endif; ?>
    <script>
            $(document).ready(function () {
                /* When click show user */

                 // add modal
                 if($('.select-day-type-edit').length > 0) {
                    $('.select-day-type-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_shift_type')
                    });
                }


                    $('body').on('click', '#edit-shift-type', function () {
                        const editUrl = $(this).data('url');
                        $('#edit-name-shift-type').val('')


                        $.get(editUrl, (data) => {
                            $('#edit-name-shift-type').val(data.name)

                            const urlNow = '<?php echo e(Request::url()); ?>'
                            $('#edit-form-shift-type').attr('action', urlNow + '/' + data.id);
                        })
                    });

                $('body').on('click', '#delete-shift-type', function(){
                    const deleteURL = $(this).data('url');
                    $('#form-delete-shift-type').attr('action', deleteURL);
                })
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/shift-type/index.blade.php ENDPATH**/ ?>