    <!-- Add overtime Modal -->
    <div id="add_loan" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Loan</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('loans.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                
                                    <div class="form-group">
                                        <label>Employee <span class="text-danger">*</span></label>
                                        <select class="form-control select-employee" id="employee_id" name="employee_id">
                                            <?php if( !is_null(Auth::user()->employee) ): ?>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($e->id == Auth::user()->employee->id): ?>
                                                        <option value="<?php echo e($e->id); ?>" selected><?php echo e($e->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option value="0">Select Employee</option>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>

                                        <?php if($errors->has('employee_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('employee_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                

                                <div class="form-group">
                                    <label for="loan_type_id" class="form-label">Loan Type</label>
                                    <select name="loan_type_id" id="loan_type_id" class="form-control select-cash-type">
                                        <option value="0">Select Loan Type</option>
                                        <?php $__currentLoopData = $loanType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                        <?php if($errors->has('loan_type_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('loan_type_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>

                                <label for="installment" class="form-label">Installment</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" placeholder="Installment Plan" name="installment"  id="installment">
                                    <span class="input-group-text">X</span>

                                        <?php if($errors->has('installment')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('installment')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="amount" class="form-label">Amount</label>
                                    <input type="number" class="form-control" placeholder="Amount" name="amount"  id="amount">

                                        <?php if($errors->has('amount')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('amount')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Add User Modal -->

    <!-- Edit Overtime Modal -->
    <div id="edit_loan" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Leave</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" id="edit-form-loan" method="POST">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                
                                    <div class="form-group">
                                        <label>Employee <span class="text-danger">*</span></label>
                                        <select class="form-control select-employee-edit" id="employee_id_edit" name="employee_id">
                                            <?php if( !is_null(Auth::user()->employee) ): ?>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($e->id == Auth::user()->employee->id): ?>
                                                        <option value="<?php echo e($e->id); ?>" selected><?php echo e($e->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option value="0">Select Employee</option>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>

                                        <?php if($errors->has('employee_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('employee_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                

                                <div class="form-group">
                                    <label for="loan_type_id" class="form-label">Loan Type</label>
                                    <select name="loan_type_id" id="loan_type_id_edit" class="form-control select-cash-type-edit">
                                        <option value="0">Select Loan Type</option>
                                        <?php $__currentLoopData = $loanType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                        <?php if($errors->has('loan_type_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('loan_type_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>

                                <label for="installment" class="form-label">Installment</label>
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" placeholder="Installment Plan" name="installment"  id="installment-edit">
                                    <span class="input-group-text">X</span>

                                        <?php if($errors->has('installment')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('installment')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="amount" class="form-label">Amount</label>
                                    <input type="number" class="form-control" placeholder="Amount" name="amount"  id="amount-edit">

                                        <?php if($errors->has('amount')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('amount')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Edit User Modal -->

    <!-- Delete User Modal -->
    <div class="modal custom-modal fade" id="delete_loan" role="dialog">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-header">
                        <h3>Delete Loan</h3>
                        <p>Are you sure want to delete?</p>
                    </div>
                    <div class="modal-btn delete-action">
                        <div class="row">
                            <div class="col-6">
                                <form action="" id="form-delete-loan" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary continue-btn">Delete</button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-6">
                                <a href="javascript:void(0);" data-bs-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Delete User Modal -->



<?php /**PATH /home/pehadirm/public_html/resources/views/includes/modal/loan-modal.blade.php ENDPATH**/ ?>