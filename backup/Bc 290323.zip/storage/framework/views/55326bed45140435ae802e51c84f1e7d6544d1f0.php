<?php $__env->startSection('title', 'project'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<?php
    function formatRupiah($angka){
	$hasil_rupiah = "IDR " . number_format($angka,0,',','.');
	return $hasil_rupiah;
    }
?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Projects</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Projects</li>
                    </ul>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create project')): ?>
                    <div class="col-auto float-end ms-auto">
                        <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_project"><i class="fa fa-plus"></i> Create Project</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /Page Header -->

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>Project</th>
                                <th>Team</th>
                                <th>Deadline</th>
                                <th>Status</th>
                                <?php if(Auth::user()->can('edit project') || Auth::user()->can('delete project')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($project->project_name); ?>

                                    </td>
                                    <td>
                                        <ul class="team-members text-nowrap">
                                            <?php if(count($project->user_in_project) < 4): ?>
                                                <?php $__currentLoopData = $project->user_in_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="#" title="<?php echo e($user->user->name); ?>" data-bs-toggle="tooltip">
                                                            <img alt="" src="https://ui-avatars.com/api/?name=<?php echo e($user->user->name); ?>">
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                
                                                    <a href="#" class="all-users dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><?php echo e(count($project->user_in_project)); ?></a>
                                                    
                                                
                                            <?php endif; ?>
                                        </ul>
                                    </td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($project->end_date)->format('j F Y')); ?>

                                    </td>
                                    <td>
                                        <?php if($project->status == 'completed'): ?>
                                            <div class="status_badge badge bg-success p-2 px-3 rounded">Completed</div>
                                        <?php elseif($project->status == 'in_progress'): ?>
                                            <div class="status_badge badge bg-success p-2 px-3 rounded">In Progress</div>
                                        <?php elseif($project->status == 'on_hold'): ?>
                                            <div class="status_badge badge bg-success p-2 px-3 rounded">On Hold</div>
                                        <?php elseif($project->status == 'canceled'): ?>
                                            <div class="status_badge badge bg-success p-2 px-3 rounded">Canceled</div>
                                        <?php endif; ?>
                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit project', 'delete project'])): ?>
                                        <td class="d-flex justify-content-end">
                                            <a title="Invite User" data-url="<?php echo e(route('projects.edit', $project->id)); ?>" id="edit-leave" class="btn btn-add" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#edit_project"><i class="fa fa-user m-r-5"></i> </a>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit project')): ?>
                                                <a title="Edit" data-url="<?php echo e(route('projects.edit', $project->id)); ?>" id="edit-project" class="btn btn-add" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#edit_project"><i class="fa fa-pencil m-r-5"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete project')): ?>
                                                <a title="Delete" id="delete-project" data-url="<?php echo e(route('projects.destroy', $project->id)); ?>" class="btn btn-add" href="#" data-bs-toggle="modal" data-bs-target="#delete_project"><i class="fa fa-trash-o m-r-5"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <?php echo $__env->make('includes.modal.project-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_project').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */

                $('select#status_edit').change(function(){
                    let selectedItem = $(this).children('option:selected').val()

                    if (selectedItem == 'Rejected') {
                        $('#rejected-reason').show()
                    }else{
                        $('#rejected-reason').hide()
                    }
                })

                if($('.select-employee').length > 0) {
                    $('.select-employee').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_project')
                    });
                }

                if($('.select-project-type').length > 0) {
                    $('.select-project-type').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_project')
                    });
                }

                //edit
                if($('.select-employee-edit').length > 0) {
                    $('.select-employee-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#edit_project')
                    });
                }

                if($('.select-project-type-edit').length > 0) {
                    $('.select-project-type-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#edit_project')
                    });
                }

                    $('body').on('click', '#edit-project', function () {
                        const editUrl = $(this).data('url');

                        $.get(editUrl, (data) => {
                            $('#project_name_edit').val(data.project_name)
                            $('#client_name_edit').val(data.client)
                            $('#start_date_edit').val(data.start_date)
                            $('#end_date_edit').val(data.end_date)
                            $('#description_edit').html(data.description)
                            
                            $('#budget_edit').val(data.budget)
                            $('#estimated_hours_edit').val(data.estimated_hrs)

                            $('#status_edit option[value='+ data.status +']').attr('selected','selected');
                            $('#status_edit').val(data.status ? data.status : 0).trigger('change');
                            
                            const urlNow = '<?php echo e(Request::url()); ?>'
                            $('#edit-form-project').attr('action', urlNow + '/' + data.id);
                        })
                    });

                $('body').on('click', '#delete-project', function(){
                    const deleteURL = $(this).data('url');
                    $('#form-delete-project').attr('action', deleteURL);
                })
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/projects/index.blade.php ENDPATH**/ ?>