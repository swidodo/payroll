<?php $__env->startSection('title', 'Checklist Attendance Summary'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Checklist Attendance Summary</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Checklist Attendance Summary</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- /Page Header -->

        <div class="row justify-content-center">
            <div class="col-md-8" >
            
                <form action="<?php echo e(route('checklist-attendance-summary.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row justify-content-center">
                        <div class="col-md-6 col-lg-12" >
                            <div class="task-wrapper p-0 pt-2">
                                <div class="task-list-container">
                                    <div class="task-list-body">
                                        <ul id="task-list">
                                            <li class="task">
                                                <div class="task-container d-flex">
                                                    <span class="task-action-btn task-check d-flex align-items-center me-2">
                                                        <?php
                                                            $checked = false;
                                                            foreach ($checklists as $key => $value) {
                                                                if ($value->name == 'actual_working_day') {
                                                                    $checked = true;
                                                                }
                                                            } 
                                                        ?>
                                                        <input <?php echo e($checked ? 'checked' : ''); ?> type="checkbox" name="checklists[actual_working_day]" id="" class="action-circle large complete-btn">
                                                    </span>
                                                    <span >Actual Working Day</span>
                                                </div>
                                            </li>
                                            <li class="task">
                                                <div class="task-container d-flex">
                                                    <span class="task-action-btn task-check d-flex align-items-center me-2">
                                                        <?php
                                                            $checked = false;
                                                            foreach ($checklists as $key => $value) {
                                                                if ($value->name == 'schedule_working_day') {
                                                                    $checked = true;
                                                                }
                                                            } 
                                                        ?>
                                                        <input <?php echo e($checked ? 'checked' : ''); ?> type="checkbox" name="checklists[schedule_working_day]" id="" class="action-circle large complete-btn">
                                                    </span>
                                                    <span >Schedule Working Day</span>
                                                </div>
                                            </li>
                                            <li class=" task">
                                                <div class="task-container d-flex">
                                                    <span class="task-action-btn task-check d-flex align-items-center me-2">
                                                        <?php
                                                            $checked = false;
                                                            foreach ($checklists as $key => $value) {
                                                                if ($value->name == 'dayoff') {
                                                                    $checked = true;
                                                                }
                                                            } 
                                                        ?>
                                                        <input <?php echo e($checked ? 'checked' : ''); ?> type="checkbox" name="checklists[dayoff]" id="" class="action-circle large complete-btn">
                                                    </span>
                                                    <span  >Dayoff</span>
                                                </div>
                                            </li>
                                            <li class="task">
                                                <div class="task-container d-flex">
                                                    <span class="task-action-btn task-check d-flex align-items-center me-2">
                                                        <?php
                                                            $checked = false;
                                                            foreach ($checklists as $key => $value) {
                                                                if ($value->name == 'national_holiday') {
                                                                    $checked = true;
                                                                }
                                                            } 
                                                        ?>
                                                        <input <?php echo e($checked ? 'checked' : ''); ?> type="checkbox" name="checklists[national_holiday]" id="" class="action-circle large complete-btn">
                                                    </span>
                                                    <span  >National Holiday</span>
                                                </div>
                                            </li>
                                            <li class="task">
                                                <div class="task-container d-flex">
                                                    <span class="task-action-btn task-check d-flex align-items-center me-2">
                                                        <?php
                                                            $checked = false;
                                                            foreach ($checklists as $key => $value) {
                                                                if ($value->name == 'company_holiday') {
                                                                    $checked = true;
                                                                }
                                                            } 
                                                        ?>
                                                        <input <?php echo e($checked ? 'checked' : ''); ?> type="checkbox" name="checklists[company_holiday]" id="" class="action-circle large complete-btn">
                                                    </span>
                                                    <span  >Company Holiday</span>
                                                </div>
                                            </li>
                                            <li class="task">
                                                <div class="task-container d-flex">
                                                    <span class="task-action-btn task-check d-flex align-items-center me-2">
                                                        <?php
                                                            $checked = false;
                                                            foreach ($checklists as $key => $value) {
                                                                if ($value->name == 'timeoff_code') {
                                                                    $checked = true;
                                                                }
                                                            } 
                                                        ?>
                                                        <input <?php echo e($checked ? 'checked' : ''); ?> type="checkbox" name="checklists[timeoff_code]" id="" class="action-circle large complete-btn">
                                                    </span>
                                                    <span  >Attendance/Time Off Code</span>
                                                </div>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /Page Content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/payroll/checklist-attendance-summary/index.blade.php ENDPATH**/ ?>