<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="page-title">Dashboard</h3>
                </div>
            </div>
        </div>
        <!-- /Page Header -->


        

        

        <!-- Statistics Widget -->
        
        <!-- /Statistics Widget -->

        <div class="row">
            <div class="col-md-6 d-flex">
                <div class="card card-table flex-fill">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Absent employees </h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-2">
                            <table class="table table-nowrap custom-table datatable">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Branch</th>
                                        <th>Sick</th>
                                        <th>Alpha</th>
                                        <th>Cuti</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $absentEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <?php echo e($item['employeeName']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['branch']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['totalSick']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['alpha']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['leave']); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex">
                <div class="card card-table flex-fill">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Employee Birthday</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-2">
                            <table class="table custom-table table-nowrap datatable">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Branch</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $birthdayEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <?php echo e($item['employeeName']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['branch']); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item['birth']); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 d-flex">
                <div class="card card-table flex-fill">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Employee Contract Will End </h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-2">
                            <table class="table table-nowrap custom-table datatable">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th>Branch</th>
                                        <th>End Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($employeesContractWillExpire)): ?>
                                        <?php $__currentLoopData = $employeesContractWillExpire; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($item['employeeName']); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($item['branch']); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($item['end_date']); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex">
                <div class="card card-table flex-fill">
                    <div class="card-header">
                        <h3 class="card-title mb-0">Best Employee </h3>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-2">
                            <table class="table table-nowrap custom-table datatable">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($bestEmployees)): ?>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $bestEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($no++); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($item['name']); ?>

                                                </td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

        

    </div>
    <!-- /Page Content -->

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Chart CSS -->
    
     <!-- Datatable CSS -->
     <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

     <!-- Chart JS -->
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/dashboard/dashboard-company.blade.php ENDPATH**/ ?>