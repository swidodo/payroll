<?php $__env->startSection('title', 'On Duty'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">List On Duty</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">List On Duty</li>
                    </ul>
                </div>
                <div class="col-auto float-end ms-auto">
                    <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#modal_export"> Report</a>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create on duty')): ?>
                    <div class="col-auto float-end ms-auto">
                        <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_travel"><i class="fa fa-plus"></i> New Request</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /Page Header -->

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive" style="overflow-x: visible">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Purpose of Trip</th>
                                <th>Country</th>
                                <th>Description</th>
                                <th>Status</th>
                                <?php if(Auth::user()->can('edit on duty') || Auth::user()->can('delete on duty')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $travels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $travel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($travel->employee->name ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($travel->start_date ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($travel->end_date ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($travel->purpose_of_visit ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($travel->place_of_visit ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($travel->description ?? '-'); ?>

                                    </td>
                                   
                                    <td>
                                        <?php if($travel->status=="Pending"): ?>
                                            <div class="status_badge badge bg-warning p-2 px-3 rounded"><?php echo e($travel->status ?? '-'); ?></div>
                                        <?php elseif($travel->status=="Approved"): ?>
                                            <div class="status_badge badge bg-success p-2 px-3 rounded"><?php echo e($travel->status ?? '-'); ?></div>
                                        <?php elseif($travel->status=="Rejected"): ?>
                                            <a href="<?php echo e(route('travels.show', $travel->id)); ?>" class="text-white">
                                                <div class="status_badge badge bg-danger p-2 px-3 rounded">
                                                    <?php echo e($travel->status ?? '-'); ?>

                                                </div>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit on duty', 'delete on duty'])): ?>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>

                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit on duty')): ?>
                                                        <a  data-url="<?php echo e(route('travels.edit', $travel->id)); ?>" id="edit-travel" class="dropdown-item" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#edit_travel"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete on duty')): ?>
                                                        <a id="delete-travel" data-url="<?php echo e(route('travels.destroy', $travel->id)); ?>" class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete_travel"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <?php echo $__env->make('includes.modal.travel-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_travel').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */

                $('select#status_edit').change(function(){
                    let selectedItem = $(this).children('option:selected').val()

                    if (selectedItem == 'Rejected') {
                        $('#rejected-reason').show()
                    }else{
                        $('#rejected-reason').hide()
                    }
                })

                if($('.select-employee').length > 0) {
                    $('.select-employee').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_travel')
                    });
                }

                if($('.select-employee-edit').length > 0) {
                    $('.select-employee-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#edit_travel')
                    });
                }

                $('body').on('click', '#edit-travel', function () {
                    const editUrl = $(this).data('url');
                    $('.wrapper-approver').empty()


                    $.get(editUrl, (data) => {
                        // 3 tier approval
                        if(data.level_approve != null)
                            {
                                $('#level_approve').attr('value', data.level_approve)
                                $('#form-status').show()
                            }
                            if(data.leaveApprovals.length > 0)
                            {
                                $.each(data.leaveApprovals, function (indexInArray, valueOfElement) { 
                                    if (valueOfElement !== null) {
                                        $('.wrapper-approver').append(`<input disabled style="margin-bottom: 3px" class="form-control"  type="text" value="${valueOfElement.approver}">`)
                                        $('#approver').show()
                                    }
                                });
                            }
                            // 3 tier approval

                        $('#start_date_edit').val(data[0].start_date)
                        $('#end_date_edit').val(data[0].end_date)
                        $('#purpose_of_visit_edit').val(data[0].purpose_of_visit)
                        $('#place_of_visit_edit').val(data[0].place_of_visit)
                        $('#description_edit').html(data[0].description)
                        
                        $('#employee_id_edit option[value='+ data[0].employee_id +']').attr('selected','selected');
                        $('#employee_id_edit').val(data[0].employee_id ? data[0].employee_id : 0).trigger('change');

                        $('#status_edit option[value='+ data[0].status +']').attr('selected','selected');
                            $('#status_edit').val(data[0].status ? data[0].status : 0).trigger('change');

                        const urlNow = '<?php echo e(Request::url()); ?>'
                        $('#edit-form-travel').attr('action', urlNow + '/' + data[0].id);
                    })
                });

                $('body').on('click', '#delete-travel', function(){
                    const deleteURL = $(this).data('url');
                    $('#form-delete-travel').attr('action', deleteURL);
                })
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/travel/index.blade.php ENDPATH**/ ?>