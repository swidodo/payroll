    <!-- Add overtime Modal -->
    <div id="add_payroll" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Payroll</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('payroll.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                
                                    <div class="form-group">
                                        <label>Employee <span class="text-danger">*</span></label>
                                        <select class="form-control select-employee" id="employee_id" name="employee_id">
                                            <?php if( !is_null(Auth::user()->employee) ): ?>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($e->id == Auth::user()->employee->id): ?>
                                                        <option value="<?php echo e($e->id); ?>" selected><?php echo e($e->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option value="0">Select Employee</option>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>

                                        <?php if($errors->has('employee_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('employee_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                

                                <div class="form-group">
                                    <label for="payslip_type_id" class="form-label">Payslip Type</label>
                                    <select name="payslip_type_id" id="payslip_type_id" class="form-control select-payroll-type">
                                        <option value="0">Select Payslip Type</option>
                                        <?php $__currentLoopData = $payslipType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                        <?php if($errors->has('payslip_type_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('payslip_type_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="amount" class="form-label">Amount</label>
                                    <input type="number" class="form-control" placeholder="Amount" name="amount"  id="amount">

                                        <?php if($errors->has('amount')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('amount')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Add User Modal -->

    <!-- Edit Overtime Modal -->
    <div id="edit_payroll" class="modal custom-modal fade" role="dialog">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Leave</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" id="edit-form-payroll" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Employee <span class="text-danger">*</span></label>
                                        <select class="form-control select-employee-edit" id="employee_id_edit" name="employee_id">
                                            <?php if( !is_null(Auth::user()->employee) ): ?>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($e->id == Auth::user()->employee->id): ?>
                                                        <option value="<?php echo e($e->id); ?>" selected><?php echo e($e->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <option value="0">Select Employee</option>
                                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>

                                        <?php if($errors->has('employee_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('employee_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                <div class="form-group">
                                    <label for="payslip_type_id" class="form-label">Payslip Type</label>
                                    <select name="payslip_type_id" id="payslip_type_id_edit" class="form-control select-payroll-type">
                                        <option value="0">Select Payslip Type</option>
                                        <?php $__currentLoopData = $payslipType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                        <?php if($errors->has('payslip_type_id')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('payslip_type_id')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="amount" class="form-label">Amount</label>
                                    <input type="number" class="form-control" placeholder="Amount" name="amount"  id="amount_edit">

                                        <?php if($errors->has('amount')): ?>
                                            <div class="text-danger" role="alert">
                                                <small><strong><?php echo e($errors->get('amount')[0]); ?></strong></small>
                                            </div>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="submit-section">
                            <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- /Edit User Modal -->

    <!-- Delete User Modal -->
    <div class="modal custom-modal fade" id="delete_payroll" role="dialog">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-header">
                        <h3>Delete Payroll</h3>
                        <p>Are you sure want to delete?</p>
                    </div>
                    <div class="modal-btn delete-action">
                        <div class="row">
                            <div class="col-6">
                                <form action="" id="form-delete-payroll" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary continue-btn">Delete</button>
                                    </div>
                                </form>
                            </div>
                            <div class="col-6">
                                <a href="javascript:void(0);" data-bs-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Delete User Modal -->



<?php /**PATH /home/pehadirm/public_html/resources/views/includes/modal/payroll-modal.blade.php ENDPATH**/ ?>