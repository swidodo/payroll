<?php $__env->startSection('title', 'Loan'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<?php
    function formatRupiah($angka){
	$hasil_rupiah = "IDR " . number_format($angka,0,',','.');
	return $hasil_rupiah;
    }
?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Loan</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Loan</li>
                    </ul>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create loan')): ?>
                    <div class="col-auto float-end ms-auto">
                        <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_loan"><i class="fa fa-plus"></i> New Loan</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /Page Header -->


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive" style="overflow-x: visible">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>Employee Name</th>
                                <th>Type</th>
                                <th>Installment</th>
                                <th>Current Installment</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <?php if(Auth::user()->can('edit loan') || Auth::user()->can('delete loan')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($loan->employee->name  ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($loan->loan_type->name ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($loan->installment.'x' ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($loan->number_of_installment ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e(formatRupiah($loan->amount)  ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php if($loan->status=="ongoing"): ?>
                                            <div class="status_badge badge bg-warning p-2 px-3 rounded"><?php echo e(ucwords($loan->status) ?? '-'); ?></div>
                                        <?php elseif($loan->status=="paid off"): ?>
                                            <div class="status_badge badge bg-success p-2 px-3 rounded"><?php echo e(ucwords($loan->status) ?? '-'); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit loan', 'delete loan'])): ?>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>

                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit loan')): ?>
                                                        <a  data-url="<?php echo e(route('loans.edit', $loan->id)); ?>" id="edit-loan" class="dropdown-item" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#edit_loan"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete loan')): ?>
                                                        <a id="delete-loan" data-url="<?php echo e(route('loans.destroy', $loan->id)); ?>" class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete_loan"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <?php echo $__env->make('includes.modal.loan-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_loan').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */

                $('select#status_edit').change(function(){
                    let selectedItem = $(this).children('option:selected').val()

                    if (selectedItem == 'Rejected') {
                        $('#rejected-reason').show()
                    }else{
                        $('#rejected-reason').hide()
                    }
                })

                if($('.select-employee').length > 0) {
                    $('.select-employee').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_loan')
                    });
                }

                if($('.select-cash-type').length > 0) {
                    $('.select-cash-type').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_loan')
                    });
                }

                //edit
                if($('.select-employee-edit').length > 0) {
                    $('.select-employee-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#edit_loan')
                    });
                }

                if($('.select-cash-type-edit').length > 0) {
                    $('.select-cash-type-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#edit_loan')
                    });
                }

                    $('body').on('click', '#edit-loan', function () {
                        const editUrl = $(this).data('url');
                        // $('#edit-name-branch').val('')


                        $.get(editUrl, (data) => {
                            console.log(data);
                            $('#amount-edit').val(data.amount)
                            $('#installment-edit').val(data.installment)
                            
                            $('#employee_id_edit option[value='+ data.employee_id +']').attr('selected','selected');
                            $('#employee_id_edit').val(data.employee_id ? data.employee_id : 0).trigger('change');

                            $('#loan_type_id_edit option[value='+ data.loan_type_id +']').attr('selected','selected');
                            $('#loan_type_id_edit').val(data.loan_type_id ? data.loan_type_id : 0).trigger('change');

                            const urlNow = '<?php echo e(Request::url()); ?>'
                            $('#edit-form-loan').attr('action', urlNow + '/' + data.id);
                        })
                    });

                $('body').on('click', '#delete-loan', function(){
                    const deleteURL = $(this).data('url');
                    $('#form-delete-loan').attr('action', deleteURL);
                })
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/loan/index.blade.php ENDPATH**/ ?>