<!-- Add  Modal -->
<div id="add_set_ptkp" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">New Set PTKP</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('set-ptkp.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Employee <span class="text-danger">*</span></label>
                                <select  class="form-control select-employee" name="employee_id" id="employee_id_add" required>
                                    <?php if( !is_null(Auth::user()->employee) ): ?>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($e->id == Auth::user()->employee->id): ?>
                                                <option value="<?php echo e($e->id); ?>"  selected><?php echo e($e->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="0">Change Employee ID</option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php if($errors->has('employee_id')): ?>
                                <div class="text-danger" role="alert">
                                    <small><strong><?php echo e($errors->get('employee_id')[0]); ?></strong></small>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="" id="pills-tabContent">
                                <div class="" id="pills-staff" role="tabpanel" aria-labelledby="pills-staff-tab">
                                    <?php
                                         $modules=['tk_0', 'tk_1', 'tk_2', 'tk_3', 'k_0', 'k_1', 'k_2', 'k_3', 'ki0', 'ki1', 'ki2', 'ki3'];
                                    ?>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>
                                                        </th>
                                                        <th>PTKP</th>
                                                    </tr>
                                                    </thead>
                                                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $moduleMerged = $module;
                                                            $split = explode('_', $module);
                                                            if (count($split) > 1) {
                                                                $moduleMerged = $split[0].$split[1];
                                                            }
                                                        ?>
                                                        <tbody>
                                                            <tr>
                                                                <td>
                                                                    <div class="col-md-3 custom-control custom-checkbox">
                                                                        <input class="form-check-input isscheck staff_checkall isscheck_" type="checkbox" name="ptkp[]" value="<?php echo e($module); ?>" id="">
                                                                    </div>
                                                                </td>
                                                                <td><label class="ischeck staff_checkall" data-id="<?php echo e(str_replace(' ', '', str_replace('&', '', $module))); ?>"><?php echo e(strtoupper($moduleMerged)); ?></label></td>
                                                            </tr>
                                                        </tbody>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Add User Modal -->

<!-- Edit User Modal -->
<div id="edit_set_ptkp" class="modal custom-modal fade" role="dialog">≈
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Role</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="edit-form-set-ptkp" action="" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label>Employee <span class="text-danger">*</span></label>
                                <select  class="form-control select-employee-edit" name="employee_id" id="employee_id_edit" required>
                                    <?php if( !is_null(Auth::user()->employee) ): ?>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($e->id == Auth::user()->employee->id): ?>
                                                <option value="<?php echo e($e->id); ?>"  selected><?php echo e($e->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <option value="0">Change Employee ID</option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($e->id); ?>"><?php echo e($e->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>

                                <?php if($errors->has('employee_id')): ?>
                                <div class="text-danger" role="alert">
                                    <small><strong><?php echo e($errors->get('employee_id')[0]); ?></strong></small>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="" id="pills-tabContent">
                                <div class="" id="pills-staff" role="tabpanel" aria-labelledby="pills-staff-tab">
                                    <?php
                                        $modules=['tk_0', 'tk_1', 'tk_2', 'tk_3', 'k_0', 'k_1', 'k_2', 'k_3', 'ki0', 'ki1', 'ki2', 'ki3'];
                                    ?>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <table class="table mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>
                                                        </th>
                                                        <th>PTKP</th>
                                                    </tr>
                                                    </thead>
                                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $moduleMerged = $module;
                                                            $split = explode('_', $module);
                                                            if (count($split) > 1) {
                                                                $moduleMerged = $split[0].$split[1];
                                                            }
                                                        ?>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                <div class="col-md-3 custom-control custom-checkbox">
                                                                    <input class="form-check-input isscheck staff_checkall isscheck_" type="checkbox" name="ptkp[]" value="<?php echo e($module); ?>" id="ptkp_edit_<?php echo e($module); ?>">
                                                                </div>
                                                            </td>
                                                            <td><label class="ischeck staff_checkall" data-id="<?php echo e(str_replace(' ', '', str_replace('&', '', $module))); ?>"><?php echo e(strtoupper($module)); ?></label></td>
                                                        </tr>
                                                    </tbody>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Edit User Modal -->

 <!-- Delete User Modal -->
 <div class="modal custom-modal fade" id="delete_set_ptkp" role="dialog">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-header">
                    <h3>Delete Role</h3>
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-btn delete-action">
                    <div class="row">
                        <div class="col-6">
                            <form action="" id="role-delete-form" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary continue-btn">Delete</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-6">
                            <a href="javascript:void(0);" data-bs-dismiss="modal" class="btn btn-primary cancel-btn">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Delete User Modal -->
<?php /**PATH /home/pehadirm/public_html/resources/views/includes/modal/set-ptkp-modal.blade.php ENDPATH**/ ?>