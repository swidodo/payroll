<?php

namespace App\Http\Controllers;

use App\Models\AttendanceEmployee;
use App\Models\Employee;
use App\Models\ShiftSchedule;
use App\Models\Timesheet;
use App\Models\Utility;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public  function index()
    {
        if (Auth::user()->type == 'company') {
            $employees = Employee::where('created_by', '=', Auth::user()->creatorId())->get();

            $data = [];
            foreach ($employees as $key => $value) {
                $attendanceSts     = AttendanceEmployee::where('employee_id', $value->id)
                    ->whereBetween('date', [$value->company_doj, now()])
                    ->where('status', '!=', 'Present')
                    ->where('status', '!=', 'Leave')
                    ->where('status', '!=', 'Permit')
                    ->where('status', '!=', 'Sick With Letter')
                    ->get()
                    ->count();
                $attendanceSds     = AttendanceEmployee::where('employee_id', $value->id)
                    ->whereBetween('date', [$value->company_doj, now()])
                    ->where('status', 'Sick With Letter')
                    ->get()
                    ->count();
                $attendanceIzn     = AttendanceEmployee::where('employee_id', $value->id)
                    ->whereBetween('date', [$value->company_doj, now()])
                    ->where('status', 'Permit')
                    ->get()
                    ->count();
                $attendanceCt     = AttendanceEmployee::where('employee_id', $value->id)
                    ->whereBetween('date', [$value->company_doj, now()])
                    ->where('status', 'Leave')
                    ->get()
                    ->count();



                $employeeName = $value->name;
                $branch    = $value->branch->name;
                $totalSick = $attendanceSds;
                $leave     = $attendanceCt;
                $permit    = $attendanceIzn;
                $alpha     = $attendanceSts;

                if (now()->format('Y-m-d') < $value->company_doe) {
                    $diffInMonth = Carbon::parse($value->company_doe)->diffInMonths(now()->format('Y-m-d'));
                    if ($diffInMonth <= 3) {
                        $data['employeesContractWillExpire'][] = [
                            'employeeName'  => $employeeName,
                            'branch'        => $branch,
                            'end_date'      => Carbon::parse($value->company_doe)->format('j F Y'),
                        ];
                    }
                }

                $data['absentEmployees'][] = [
                    'employeeName'  => $employeeName,
                    'branch'        => $branch,
                    'totalSick'     => $totalSick,
                    'leave'         => $leave,
                    'alpha'         => $alpha,
                ];
                $data['birthdayEmployees'][] = [
                    'employeeName'  => $employeeName,
                    'branch'        => $branch,
                    'birth'         => Carbon::parse($value->dob)->format('j F Y'),
                ];
            }
            $data['bestEmployees']     = AttendanceEmployee::select('employees.name', DB::raw('count(*) total_attendance'))
                ->join('employees', 'attendance_employees.employee_id', '=', 'employees.id')
                // ->leftJoin('branches', 'employees.branch_id', '=', 'branches.id')
                ->where('attendance_employees.created_by', '=', Auth::user()->creatorId())
                ->where('attendance_employees.status', 'Present')
                ->where('attendance_employees.clock_in', '!=', '00:00:00')
                ->where('attendance_employees.clock_out', '!=', '00:00:00')
                ->groupBy('employees.name')
                ->orderBy('total_attendance', 'desc')
                ->get();

            return view('pages.contents.dashboard.dashboard-company', $data);
        } else {
            $employee = Employee::where('user_id', Auth::user()->id)->first();
            $attendanceStatus = $employee->present_status($employee->id, date('Y-m-d'));
            $attendanceEmployee = AttendanceEmployee::where('employee_id', $employee->id)->where('date', date('Y-m-d'))->orderBy('id', 'desc')->first();
            $shiftSchedule = ShiftSchedule::where('employee_id', Auth::user()->employee->id)->where('created_by', '=', Auth::user()->creatorId())->where('schedule_date', date('Y-m-d'))->first();
            $timesheet = Timesheet::where('employee_id', Auth::user()->employee->id)->where('created_by', '=', Auth::user()->creatorId())->where('start_date', '<=', date('Y-m-d'))->where('end_date', '>=', date('Y-m-d'))->first();

            return view('pages.contents.dashboard.dashboard', compact('employee', 'attendanceStatus', 'attendanceEmployee', 'shiftSchedule', 'timesheet'));
        }
    }
}
