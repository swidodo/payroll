<!-- jQuery -->
<script src="{{asset('assets/js/jquery-3.6.0.min.js')}}"></script>

<!-- Bootstrap Core JS -->
<script src="{{asset('assets/js/bootstrap.bundle.min.js')}}"></script>


 <!-- Theme Settings JS -->
<script src="{{asset('assets/js/layout.js')}}"></script>
<script src="{{asset('assets/js/theme-settings.js')}}"></script>
<script src="{{asset('assets/js/greedynav.js')}}"></script>

<!-- Custom JS -->
<script src="{{asset('assets/js/app.js')}}"></script>

