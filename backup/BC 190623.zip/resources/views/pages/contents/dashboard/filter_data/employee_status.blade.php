
<div class="progress mb-2">
    <div id="ides-progress-jobholder" class="progress-bar bg-purple" role="progressbar" aria-valuemin="0" aria-valuemax="100">0%</div>
</div>
<div class="progress mb-2">
    <div id="ides-progress-contract" class="progress-bar bg-warning" role="progressbar" aria-valuemin="0" aria-valuemax="100">0%</div>
</div>
<div class="progress mb-2">
    <div id="ides-progress-freelance" class="progress-bar bg-success" role="progressbar" aria-valuemin="0" aria-valuemax="100">0%</div>
</div>
<div id="wrapper-employement-status">
    <p class="d-block">Total &nbsp;: <span id="ides-total-employee" class="text-end">0</span></p>
    <hr>
    <p><i class="fa fa-dot-circle-o text-purple me-2"></i>Jobholder <span class="float-end" id="ides-jobholder">0</span></p>
    <p><i class="fa fa-dot-circle-o text-warning me-2"></i>Contract <span class="float-end" id="ides-contract">0</span></p>
    <p><i class="fa fa-dot-circle-o text-success me-2"></i>Freelance <span class="float-end" id="ides-freelance">0</span></p>
</div>

