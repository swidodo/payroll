<div>
    <canvas id="myChart" height="300"></canvas>
</div>

