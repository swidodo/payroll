<div>
    <canvas id="lenghtChart" height="400" width="400"></canvas>
</div>

