<div id="chart_education-js">
</div>
<div id="wrapper-employement-status">
    <p class="d-block">Total &nbsp;: <span id="ides-total-employee" class="text-end">0</span></p>
    <hr>
    <div  class="row" id="des_education">
    </div>
</div>

