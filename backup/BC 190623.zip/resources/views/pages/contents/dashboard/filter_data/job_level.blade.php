<div>
    <canvas id="jobChart" height="300"></canvas>
</div>

