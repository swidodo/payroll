<?php

namespace App\Http\Controllers\HRM;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Exports\EmployeesExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class EmployeeReportController extends Controller
{
    //
    public function exportExcel(Request $request){
        return Excel::download(new EmployeesExport($request), 'Employee Report.xlsx');
    }
    public function employee_status(){
        $status = DB::table('v_employee_status')
                    ->select('*')
                    ->get();
        $response['data'] = $status;
        return response()->json($response);
    }
    public function employee_jobLevel(){
        $job = DB::table('v_employee_joblevel')
                    ->select('*')
                    ->get();
        $response['data'] = $job;
        return response()->json($response);
    }
    public function employee_education(){
        $education = DB::table('v_employee_education')
                    ->select('*')
                    ->get();
        $total   = DB::table('v_employee_education')
                    ->select('count')
                    ->get();
        $response['data'] = $education;
        $response['total'] = $total;
        return response()->json($response);
    }
    public function employee_gender(){
        $gender = DB::table('v_employee_gender')
                    ->select('*')
                    ->get();
        $response['data'] = $gender;
        return response()->json($response);
    }
    public function employee_age_average(){
        $age = DB::table('v_employee_age_average')
                    ->select('*')
                    ->get();
        $response['data'] = $age;
        return response()->json($response);
    }
    public function employee_active_staff(){
        $staff = DB::table('v_employee_active_staff')
                    ->select('*')
                    ->get();
        $response['data'] = $staff;
        return response()->json($response);
    }
    public function employee_lenght_of_service(){
        $service3 = DB::table('v_lenght_of_service')
                    ->select(DB::raw('SUM(subtotal) as tot'))
                    ->where('service' ,'<=',3)
                    ->get();
        $service5 = DB::table('v_lenght_of_service')
                    ->select(DB::raw('SUM(subtotal) as tot'))
                    ->where('service', '>', 3)
                    ->where('service', '<=' ,5)
                    ->get();
        $service10 = DB::table('v_lenght_of_service')
                    ->select(DB::raw('SUM(subtotal) as tot'))
                    ->where('service' ,'>', 5)
                    ->where('service', '<=', 10)
                    ->get();
        $service15 = DB::table('v_lenght_of_service')
                    ->select(DB::raw('SUM(subtotal) as tot'))
                    ->where('service', '>', 10)
                    ->where('service', '<=', 15)
                    ->get();
        $service20 = DB::table('v_lenght_of_service')
                    ->select(DB::raw('SUM(subtotal) as tot'))
                    ->where('service', '>', 15)
                    ->where('service','<=', 20)
                    ->get();
        $service_30 = DB::table('v_lenght_of_service')
                    ->select(DB::raw('SUM(subtotal) as tot'))
                    ->where('service', '>', 20)
                    ->get();
        $response['lenght_3']  = $service3 ;
        $response['lenght_5']  = $service5;
        $response['lenght_10'] = $service10;
        $response['lenght_15'] = $service15;
        $response['lenght_20'] = $service20;
        $response['lenght_30'] = $service_30 ;
        return response()->json($response);
    }
}
