<!-- jQuery -->
<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>

<!-- Bootstrap Core JS -->
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>


 <!-- Theme Settings JS -->
<script src="<?php echo e(asset('assets/js/layout.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/theme-settings.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/greedynav.js')); ?>"></script>

<!-- Custom JS -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

<?php /**PATH /home/pehadirm/public_html/resources/views/includes/script-auth.blade.php ENDPATH**/ ?>