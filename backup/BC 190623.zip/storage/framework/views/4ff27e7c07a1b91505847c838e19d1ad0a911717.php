<?php $__env->startSection('title', 'Employees'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h3 class="page-title">Manage Employee</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Employees</li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <div class="d-flex justify-content-center">
                        <div>
                            <button id="import_excel" class="btn btn-warning rounded-pill me-2"><i class="fa fa-download"></i> Import</button>
                        </div>
                        <div>
                            <button id="export_excel" class="btn btn-warning rounded-pill"><i class="fa fa-upload"></i> Export</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Header -->
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive" style="overflow-x: visible">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>Employee ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Branch</th>
                                <th>Date Of Joining</th>
                                <th>Status</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete employee')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <h2 class="table-avatar">
                                         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show employee profile')): ?>
                                            <a href="<?php echo e(route('employees.show',$employee->id)); ?>" class="btn btn-outline-primary"><?php echo e('#'.$employee->employee_id); ?></a>
                                        <?php else: ?>
                                            
                                            <a href="#" class="btn btn-outline-primary"><?php echo e($employee->employee_id); ?></a>
                                        <?php endif; ?>
                                    </h2>
                                </td>
                                <td class="font-style"><?php echo e($employee->name ?? ''); ?></td>
                                <td><?php echo e($employee->email ?? ''); ?></td>
                                <td><?php echo e($employee->phone ?? ''); ?></td>
                                <td class="font-style"><?php echo e($employee->branch->name ?? ''); ?></td>
                                <td class="font-style"><?php echo e($employee->company_doj ?  Auth::user()->dateFormat($employee->company_doj) : '-'); ?></td>
                                <td>
                                    <?php if(strtolower($employee->status) == 'active'): ?>
                                            <span class="badge bg-inverse-success"><?php echo e(ucwords($employee->status)); ?></span>
                                    <?php elseif(strtolower($employee->status) == 'fired'): ?>
                                        <span class="badge bg-inverse-danger"><?php echo e(ucwords($employee->status)); ?></span>
                                    <?php elseif(strtolower($employee->status) == 'pension'): ?>
                                        <span class="badge bg-inverse-info"><?php echo e(ucwords($employee->status)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit employee', 'delete employee'])): ?>
                                    <td class="text-end">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>

                                            <div class="dropdown-menu dropdown-menu-right">
                                                <?php if(strtolower($employee->status) == 'active'): ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit employee')): ?>
                                                        <a  data-url="" id="edit-employee" class="dropdown-item" href="<?php echo e(route('employees.edit', $employee->id)); ?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete employee')): ?>
                                                    <a id="delete-employee" data-url="<?php echo e(route('employees.destroy', $employee->id)); ?>" class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete_employee"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                    </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <?php echo $__env->make('includes.modal.employees-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.modal.report.employee.modal-export-excel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.modal.employee-import-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_user').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */

                $('body').on('click', '#delete-employee', function(){
                    const deleteURL = $(this).data('url');
                    $('#employee-destroy-form').attr('action', deleteURL);
                })
                $('#export_excel').on('click', function(){
                    $('#ExportExcelModal').modal('show');
                });
                $('#import_excel').on('click', function(){
                    $('#ImportExcelModal').modal('show');
                });
            });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/employee/index.blade.php ENDPATH**/ ?>