

<table>
    <thead>
        <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Identity Card Number</th>
            <th>Family Card Number</th>
            <th>NPWP Number</th>
            <th>Dob</th>
            <th>Gender</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Email</th>
            <th>Password</th>
            <th>Employe ID</th>
            <th>Branch</th>
            <th>Department ID</th>
            <th>Designation ID</th>
            <th>Company Doj</th>
            <th>Company Doe</th>
            <th>Document</th>
            <th>Account Holder Name</th>
            <th>Account Number</th>
            <th>Bank Name</th>
            <th>Bank Code</th>
            <th>Branch Location</th>
            <th>Tax payer ID</th>
            <th>Salary Type</th>
            <th>Salary</th>
            <th>Net Salary</th>
            <th>Is Active</th>
            <th>Created By</th>
            <th>Level Approval</th>
            <th>Leave Type</th>
            <th>Employee Type</th>
            <th>Marital Status</th>
            <th>Total Leave</th>
            <th>Total Leave Remaining</th>
            <th>Out Date</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($employ->user_id); ?></td>
            <td><?php echo e($employ->name); ?></td>
            <td><?php echo e($employ->identity_card); ?></td>
            <td><?php echo e($employ->family_card); ?></td>
            <td><?php echo e($employ->npwp_number); ?></td>
            <td><?php echo e($employ->dob); ?></td>
            <td><?php echo e($employ->gender); ?></td>
            <td><?php echo e($employ->phone); ?></td>
            <td><?php echo e($employ->address); ?></td>
            <td><?php echo e($employ->email); ?></td>
            <td><?php echo e($employ->password); ?></td>
            <td><?php echo e($employ->employee_id); ?></td>
            <td><?php echo e($employ->branch_id); ?></td>
            <td><?php echo e($employ->department_id); ?></td>
            <td><?php echo e($employ->designation_id); ?></td>
            <td><?php echo e($employ->company_doj); ?></td>
            <td><?php echo e($employ->company_doe); ?></td>
            <td><?php echo e($employ->documents); ?></td>
            <td><?php echo e($employ->account_holder_name); ?></td>
            <td><?php echo e($employ->account_number); ?></td>
            <td><?php echo e($employ->bank_name); ?></td>
            <td><?php echo e($employ->bank_identifier_code); ?></td>
            <td><?php echo e($employ->branch_location); ?></td>
            <td><?php echo e($employ->tax_payer_id); ?></td>
            <td><?php echo e($employ->salary_type); ?></td>
            <td><?php echo e($employ->salary); ?></td>
            <td><?php echo e($employ->net_salary); ?></td>
            <td><?php echo e($employ->is_active); ?></td>
            <td><?php echo e($employ->created_by); ?></td>
            <td><?php echo e($employ->level_approval); ?></td>
            <td><?php echo e($employ->leave_type); ?></td>
            <td><?php echo e($employ->employee_type); ?></td>
            <td><?php echo e($employ->marital_status); ?></td>
            <td><?php echo e($employ->total_leave); ?></td>
            <td><?php echo e($employ->total_leave_remaining); ?></td>
            <td><?php echo e($employ->out_date); ?></td>
            <td><?php echo e($employ->status); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/employee/export-excel.blade.php ENDPATH**/ ?>