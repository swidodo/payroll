<div>
    <canvas id="myChart" height="300"></canvas>
</div>

<?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/dashboard/filter_data/age_average.blade.php ENDPATH**/ ?>