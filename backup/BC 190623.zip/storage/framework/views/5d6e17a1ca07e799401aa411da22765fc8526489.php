<div class="p-2" style="margin-top:-20px;margin-bottom:-40px">
    <div id="donut-chart"></div>
</div>
<hr>
<div id="wrapper-gender-diversity">
    <p><i class="fa fa-dot-circle-o text-purple me-2"></i>Male <span class="float-end" id="ides-gender-male">0</span></p>
    <p><i class="fa fa-dot-circle-o text-warning me-2"></i>Female <span class="float-end" id="ides-gender-female">0</span></p>
</div>
<?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/dashboard/filter_data/gender_diversity.blade.php ENDPATH**/ ?>