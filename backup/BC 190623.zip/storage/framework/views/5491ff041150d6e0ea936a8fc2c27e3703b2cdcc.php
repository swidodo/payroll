<div>
    <canvas id="lenghtChart" height="400" width="400"></canvas>
</div>

<?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/dashboard/filter_data/lenght_of_service.blade.php ENDPATH**/ ?>