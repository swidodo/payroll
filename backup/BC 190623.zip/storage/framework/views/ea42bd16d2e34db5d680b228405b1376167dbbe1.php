<?php $__env->startSection('title', 'Roles'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Manage Roles</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Roles</li>
                    </ul>
                </div>
                <div class="col-auto float-end ms-auto">
                    <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_role" title="Create New Role"><i class="fa fa-plus"></i> Add Role</a>
                </div>
            </div>
        </div>
        <!-- /Page Header -->

        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>Role</th>
                                <th>Permissions</th>
                                <?php if(Auth::user()->can('edit role') || Auth::user()->can('delete role')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($role->name); ?></td>
                                    <td class="d-flex flex-wrap pad-bot-role">
                                        <?php for($j=0; $j < count($role->permissions()->pluck('name')) ; $j++): ?>
                                            <span class="badge bg-inverse-success mt-2 ms-2"><?php echo e($role->permissions()->pluck('name')[$j]); ?></span>
                                        <?php endfor; ?>
                                    </td>
                                    <?php if(Auth::user()->can('edit role') || Auth::user()->can('delete role')): ?>
                                    <td class="text-end">
                                        <div class="dropdown dropdown-action">
                                            <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit role')): ?>
                                                    <a  data-url="<?php echo e(route('roles.edit', $role->id)); ?>" id="edit-role" class="dropdown-item" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#edit_role"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                                                    <a id="delete-role" data-url="<?php echo e(route('roles.destroy', $role->id)); ?>" class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete_role"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <?php echo $__env->make('includes.modal.roles-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
    <style>
        .pad-bot-role{
            padding-bottom: 16px !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>


    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_role').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
        $(document).ready(function () {
        $("#staff_checkall").click(function(){
            $('.staff_checkall').not(this).prop('checked', this.checked);
        });
        $("#crm_checkall").click(function(){
            $('.crm_checkall').not(this).prop('checked', this.checked);
        });
        $("#project_checkall").click(function(){
            $('.project_checkall').not(this).prop('checked', this.checked);
        });
        $("#hrm_checkall").click(function(){
            $('.hrm_checkall').not(this).prop('checked', this.checked);
        });
        $("#account_checkall").click(function(){
            $('.account_checkall').not(this).prop('checked', this.checked);
        });
        $(".ischeck").click(function(){
            var ischeck = $(this).data('id');
            $('.isscheck_'+ ischeck).prop('checked', this.checked);
        });

        $("#staff_checkall_edit").click(function(){
            $('.staff_checkall_edit').not(this).prop('checked', this.checked);
        });
        // $("#crm_checkall").click(function(){
        //     $('.crm_checkall').not(this).prop('checked', this.checked);
        // });
        // $("#project_checkall").click(function(){
        //     $('.project_checkall').not(this).prop('checked', this.checked);
        // });
        // $("#hrm_checkall").click(function(){
        //     $('.hrm_checkall').not(this).prop('checked', this.checked);
        // });
        // $("#account_checkall").click(function(){
        //     $('.account_checkall').not(this).prop('checked', this.checked);
        // });
        $(".ischeck").click(function(){
            var ischeck = $(this).data('id');
            $('.isscheckedit_'+ ischeck).prop('checked', this.checked);
        });

        $('body').on('click', '#edit-role', function () {
            $("input:checkbox").prop('checked', false)

            const editUrl = $(this).data('url');

            $.get(editUrl, (data) => {
                const {name, id : idRole} = data?.role
                const {permissions} = data

                $('#role-name').val(name);

                Object.keys(permissions).forEach(permission => {
                    if($('#permission'+permission+'edit').prop('checked') != true){
                        $('#permission'+permission+'edit').prop('checked', true)
                    }
                });

                const urlNow = '<?php echo e(Request::url()); ?>'
                $('#edit-form-role').attr('action', urlNow + '/' + idRole);

            })
        });

        $('body').on('click', '#delete-role', function(){
            const deleteURL = $(this).data('url');
            $('#role-delete-form').attr('action', deleteURL);
        })
    });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/users management/roles/index.blade.php ENDPATH**/ ?>