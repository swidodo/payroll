<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="row">
            <div class="col-md-12">
                <div class="welcome-box">
                    <div class="welcome-img">
                        <img src="https://ui-avatars.com/api/?name=<?php echo e($employee->name); ?>" alt="">
                    </div>
                    <div class="welcome-det">
                        <h3>Welcome, <?php echo e($employee->name); ?></h3>
                        <p><?php echo e(\Carbon\Carbon::now()->format('l, j F Y')); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Header -->


        <div class="row">
            <div class="col-md-4">
                <div class="card punch-status">
                    <div class="card-body">
                        <h5 class="card-title">Attendance <small class="text-muted"> <?php echo e(\Carbon\Carbon::now()->format('j M Y')); ?></small></h5>

                            <?php if($shiftSchedule): ?>
                                <?php if(!empty($attendanceStatus) && $attendanceStatus->status == 'Present'): ?>
                                    <div class="punch-det">
                                        <div class="row">
                                            <div class="col-auto">
                                                <h6>Clock In at</h6>
                                                <p> <?php echo e(\Carbon\Carbon::now()->format('j M Y').' '.\Carbon\Carbon::parse($attendanceEmployee->clock_in)->format('H:i')); ?></p>
                                            </div>
                                            <?php if(!empty($attendanceStatus) && $attendanceStatus->clock_out != '00:00:00'): ?>
                                                <div class="col-auto">
                                                    <h6>Clock Out at</h6>
                                                    <p> <?php echo e(\Carbon\Carbon::now()->format('j M Y').' '.\Carbon\Carbon::parse($attendanceEmployee->clock_out)->format('H:i')); ?></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                <?php elseif(empty($attendanceStatus)): ?>

                                <?php endif; ?>
                            <?php else: ?>
                            <div class="punch-det">
                                <div class="row justify-content-center">
                                    <div class="col-auto ">
                                        <h5 class="mb-0">You don't have shift today</h5>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                        

                        <div class="punch-btn-section">
                            <form action="<?php echo e(route('clock_store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input hidden name="clock" value="<?php echo e(!empty($attendanceStatus) && $attendanceStatus->status == 'Present' ? 'clock_out' : 'clock_in'); ?>" type="text">
                                <button <?php echo e(empty($shiftSchedule) || !empty($attendanceStatus) && $attendanceStatus->clock_out != '00:00:00' ? 'disabled' : ''); ?> type="submit" class="btn btn-primary punch-btn"><?php echo e(!empty($attendanceStatus) && $attendanceStatus->status == 'Present' ? 'Clock Out' : 'Clock In'); ?> </button>
                            </form>
                        </div>

                        
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card punch-status">
                    <div class="card-body">
                        <h5 class="card-title">Timesheet <small class="text-muted"> <?php echo e(\Carbon\Carbon::now()->format('j M Y')); ?></small></h5>

                        <?php if(!is_null($timesheet)): ?>
                            <div class="punch-det">
                                <div class="row">
                                    <div class="col-auto ">
                                        <h5 class="mb-0"><?php echo e($timesheet->task_or_project); ?></h5>
                                        <h6 class="mb-0"><?php echo e($timesheet->activity); ?></h6>
                                    </div>
                                </div>
                            </div>
                            <div class="punch-det">
                                <div class="row">
                                    <div class="col-12 d-flex justify-content-center">
                                        <h6>Record Time</h6>
                                    </div>
                                    <div class="col-6 d-flex">
                                        <h6>Start Time</h6>
                                        <p class="ms-auto"><?php echo e(is_null($timesheet->start_time) ? '00:00' : $timesheet->start_time); ?></p>
                                    </div>
                                    <div class="col-6 d-flex">
                                        <h6>End Time</h6>
                                        <p class="ms-auto"><?php echo e(is_null($timesheet->end_time) ? '00:00' :  $timesheet->end_time); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                        <div class="punch-det">
                                <div class="row">
                                    <div class="col-auto ">
                                        <h5 class="mb-0">You have no timesheet today</h5>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>



                        <div class="punch-btn-section">
                            <form action="<?php echo e(route('timesheets.record-time')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input hidden name="time_now" value="<?php echo e(date("H:i:s")); ?>" type="text">
                                <button
                                 <?php echo e(is_null($timesheet) ? 'disabled' : ''); ?> 
                                 type="submit" class="btn btn-primary punch-btn"><?php echo e(!is_null($timesheet) ? is_null($timesheet->start_time) ? 'Start' : 'End' : 'Start'); ?></button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- /Page Content -->

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Chart CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/morris/morris.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script> --}}

     <!-- Chart JS -->
    <script src="<?php echo e(asset('assets/plugins/morris/morris.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/chart.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/greedynav.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/dashboard/dashboard.blade.php ENDPATH**/ ?>