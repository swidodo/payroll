<?php $__env->startSection('title', 'Reimburst'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<?php
    function formatRupiah($angka){
	$hasil_rupiah = "IDR " . number_format($angka,2,',','.');
	return $hasil_rupiah;
    }
?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Reimburst</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Reimburst</li>
                    </ul>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create reimburst')): ?>
                    <div class="col-auto float-end ms-auto">
                        <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_reimburst"><i class="fa fa-plus"></i> New Reimburst</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /Page Header -->


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive" style="overflow-x: visible">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>Employee Name</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <?php if(Auth::user()->can('edit reimburst') || Auth::user()->can('delete reimburst')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reimburst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reimburstes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($reimburstes->employee->name  ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($reimburstes->reimburst_type->name ?? '-'); ?>

                                    </td>
                                    <td>
                                        <?php echo e(formatRupiah($reimburstes->amount)  ?? '-'); ?>

                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit reimburst', 'delete reimburst'])): ?>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>

                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit reimburst')): ?>
                                                        <a  data-url="<?php echo e(route('leaves.edit', $reimburstes->id)); ?>" id="edit-leave" class="dropdown-item" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#edit_reimburst"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete reimburst')): ?>
                                                        <a id="delete-leave" data-url="<?php echo e(route('leaves.destroy', $reimburstes->id)); ?>" class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete_reimburst"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <?php echo $__env->make('includes.modal.reimburst-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_reimburst').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */

                $('select#status_edit').change(function(){
                    let selectedItem = $(this).children('option:selected').val()

                    if (selectedItem == 'Rejected') {
                        $('#rejected-reason').show()
                    }else{
                        $('#rejected-reason').hide()
                    }
                })

                if($('.select-employee').length > 0) {
                    $('.select-employee').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_reimburst')
                    });
                }

                if($('.select-reimburst-type').length > 0) {
                    $('.select-reimburst-type').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#add_reimburst')
                    });
                }

                //edit
                if($('.select-employee-edit').length > 0) {
                    $('.select-employee-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#edit_reimburst')
                    });
                }

                if($('.select-reimburst-type-edit').length > 0) {
                    $('.select-reimburst-type-edit').select2({
                        width: '100%',
                        tags: true,
                        dropdownParent: $('#edit_reimburst')
                    });
                }

                    $('body').on('click', '#edit-leave', function () {
                        const editUrl = $(this).data('url');
                        // $('#edit-name-branch').val('')


                        $.get(editUrl, (data) => {
                            // let splitFile = data[2].attachment_reject.split('/')
                            // const lastItem = splitFile[splitFile.length - 1]
                            $('#start_date_edit').val(data[2].start_date)
                            $('#end_date_edit').val(data[2].end_date)
                            $('#leave_reason_edit').html(data[2].leave_reason)
                            $('#rejected_reason_edit').html(data[2].rejected_reason)
                            // $('#attachment_rejected_edit_anchor').attr('href', data[2].attachment_reject)
                            // $('#attachment_rejected_edit_anchor').html(lastItem)
                            
                            $('#employee_id_edit option[value='+ data[0].id +']').attr('selected','selected');
                            $('#employee_id_edit').val(data[0].id ? data[0].id : 0).trigger('change');

                            $('#leave_type_id_edit option[value='+ data[2].leave_type_id +']').attr('selected','selected');
                            $('#leave_type_id_edit').val(data[2].leave_type_id ? data[2].leave_type_id : 0).trigger('change');

                            $('#status_edit option[value='+ data[2].status +']').attr('selected','selected');
                            $('#status_edit').val(data[2].status ? data[2].status : 0).trigger('change');
                            
                            const urlNow = '<?php echo e(Request::url()); ?>'
                            $('#edit-form-leave').attr('action', urlNow + '/' + data[2].id);
                        })
                    });

                $('body').on('click', '#delete-leave', function(){
                    const deleteURL = $(this).data('url');
                    $('#form-delete-leave').attr('action', deleteURL);
                })
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/reimburst/index.blade.php ENDPATH**/ ?>