<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        
		
        
        <meta name="robots" content="noindex, nofollow">
        <title><?php echo $__env->yieldContent('title'); ?> - Pehadir</title>

		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">

        <?php echo $__env->make('includes.style-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('addon-style'); ?>

    </head>
    <body class="account-page">

		<!-- Main Wrapper -->
			<?php echo $__env->yieldContent('content'); ?>
		<!-- /Main Wrapper -->

        <?php echo $__env->yieldPushContent('prepend-script'); ?>
		<?php echo $__env->make('includes.script-auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('addon-script'); ?>
    </body>
</html>
<?php /**PATH /home/pehadirm/public_html/resources/views/layouts/auth.blade.php ENDPATH**/ ?>