<?php $__env->startSection('title', 'Branches'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Manage Payslip Type</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Payslip Type</li>
                    </ul>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create payslip type')): ?>
                    <div class="col-auto float-end ms-auto">
                        <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_payslip_type"><i class="fa fa-plus"></i> New Payslip Type</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- /Page Header -->


        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(Session::get('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive" style="overflow-x: visible">
                    <table class="table table-striped custom-table datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Payslip Type</th>
                                <th>Type</th>
                                <?php if(Auth::user()->can('edit payslip type') || Auth::user()->can('delete payslip type')): ?>
                                    <th class="text-end">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <?php
                            $no=1;
                        ?>
                        <tbody>
                            <?php $__currentLoopData = $payslipTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td>
                                        <?php echo e($type->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e(ucwords($type->type)); ?>

                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit payslip type', 'delete payslip type'])): ?>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="material-icons">more_vert</i></a>

                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit payslip type')): ?>
                                                        <a  data-url="<?php echo e(route('payslip-type.edit', $type->id)); ?>" id="edit-payslip-type" class="dropdown-item" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#edit_payslip_type"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete payslip type')): ?>
                                                        <a id="delete-payslip-type" data-url="<?php echo e(route('payslip-type.destroy', $type->id)); ?>" class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete_payslip_type"><i class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                    <?php endif; ?>

                                                </div>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- /Page Content -->

    <?php echo $__env->make('includes.modal.payslip-type-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-style'); ?>
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">

    <!-- Select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">

    <!-- Datetimepicker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('addon-script'); ?>
    <!-- Slimscroll JS -->
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    <!-- Select2 JS -->
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>

    <!-- Datetimepicker JS -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap-datetimepicker.min.js')); ?>"></script>

    <!-- Datatable JS -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <?php if(Session::has('edit-show')): ?>
    <script>
        $(window).on('load', function(){
            $('#edit_user').modal('show')
        });
    </script>
    <?php endif; ?>

    <script>
            $(document).ready(function () {
                /* When click show user */


                    $('body').on('click', '#edit-payslip-type', function () {
                        const editUrl = $(this).data('url');
                        $('#edit-name-payslip-type').val('')


                        $.get(editUrl, (data) => {
                            console.log(data.type);
                            $('#edit-name-payslip-type').val(data.name)

                            $('#edit_type option[value='+ data.type +']').attr('selected','selected');
                            $('#edit_type').val(data.type ? data.type : 0).trigger('change');
                            

                            const urlNow = '<?php echo e(Request::url()); ?>'
                            $('#edit-form-payslip-type').attr('action', urlNow + '/' + data.id);
                        })
                    });

                $('body').on('click', '#delete-payslip-type', function(){
                    const deleteURL = $(this).data('url');
                    $('#form-delete-payslip-type').attr('action', deleteURL);
                })
            });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('pages.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pehadirm/public_html/resources/views/pages/contents/payslip-type/index.blade.php ENDPATH**/ ?>