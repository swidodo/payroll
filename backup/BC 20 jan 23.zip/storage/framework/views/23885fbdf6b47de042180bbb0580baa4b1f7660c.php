<div class="header" style="background-color: #3699FF !important">

    <!-- Logo -->
    <div class="header-left">
        <a href="<?php echo e(route('dashboard')); ?>" class="logo">
            <img src="<?php echo e(asset('assets/img/logo-pehadir.jpg')); ?>" width="100"  alt="">
        </a>
        <a href="<?php echo e(route('dashboard')); ?>" class="logo2">
            <img src="<?php echo e(asset('assets/img/logo-pehadir.jpg')); ?>" width="40" height="40" alt="">
        </a>
    </div>
    <!-- /Logo -->

    <a id="toggle_btn" href="javascript:void(0);">
        <span class="bar-icon">
            <span></span>
            <span></span>
            <span></span>
        </span>
    </a>

    <!-- Header Title -->
    
    <!-- /Header Title -->

    <a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>

    <!-- Header Menu -->
    <ul class="nav user-menu">

        <!-- Search -->
        
        <!-- /Search -->

        <!-- Flag -->
        <!--<li class="nav-item dropdown has-arrow flag-nav">
            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button">
                <img src="<?php echo e(asset('assets/img/flags/us.png')); ?>" alt="" height="20"> <span>English</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                <a href="javascript:void(0);" class="dropdown-item">
                    <img src="<?php echo e(asset('assets/img/flags/us.png')); ?>" alt="" height="16"> English
                </a>
                
            </div>
        </li>-->
        <!-- /Flag -->

        <!-- Notifications -->
        
        <!-- /Notifications -->

        <!-- Message Notifications -->
        
        <!-- /Message Notifications -->

        <li class="nav-item dropdown has-arrow main-drop">
            <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <span class="user-img"><img src="assets/img/profiles/avatar-21.jpg" alt="">
                <span class="status online"></span></span>
                <span><?php echo e(Auth::user()->name); ?></span>
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="#">My Profile</a>
                <a class="dropdown-item" href="#">Settings</a>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="dropdown-item" href="settings.html">Logout</button>
                </form>
            </div>
        </li>
    </ul>
    <!-- /Header Menu -->

    <!-- Mobile Menu -->
    <div class="dropdown mobile-user-menu">
        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
        <div class="dropdown-menu dropdown-menu-right">
            <a class="dropdown-item" href="profile.html">My Profile</a>
            <a class="dropdown-item" href="settings.html">Settings</a>
            <a class="dropdown-item" href="index.html">Logout</a>
        </div>
    </div>
    <!-- /Mobile Menu -->

</div>
<?php /**PATH /home/pehadirm/public_html/resources/views/includes/header.blade.php ENDPATH**/ ?>