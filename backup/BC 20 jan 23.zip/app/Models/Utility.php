<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class Utility extends Model
{
    use HasFactory;

    protected $table = 'settings';



    public static function settings()
    {
        $data = DB::table('settings');
        if (Auth::check()) {
            $data = $data->where('created_by', '=', Auth::user()->creatorId())->get();
            if (count($data) == 0) {
                $data = DB::table('settings')->where('created_by', '=', 1)->get();
            }
        } else {
            $data->where('created_by', '=', 1);
            $data = $data->get();
        }



        $settings = [
            "site_currency" => "USD",
            "site_currency_symbol" => "$",
            "site_currency_symbol_position" => "pre",
            "site_date_format" => "M j, Y",
            "site_time_format" => "g:i A",
            "company_name" => "",
            "company_address" => "",
            "company_city" => "",
            "company_state" => "",
            "company_zipcode" => "",
            "company_country" => "",
            "company_telephone" => "",
            "company_email" => "",
            "company_email_from_name" => "",
            "invoice_prefix" => "#INVO",
            "journal_prefix" => "#JUR",
            "invoice_color" => "ffffff",
            "proposal_prefix" => "#PROP",
            "proposal_color" => "ffffff",
            "bill_prefix" => "#BILL",
            "bill_color" => "ffffff",
            "customer_prefix" => "#CUST",
            "vender_prefix" => "#VEND",
            "footer_title" => "",
            "footer_notes" => "",
            "invoice_template" => "template1",
            "bill_template" => "template1",
            "proposal_template" => "template1",
            "registration_number" => "",
            "vat_number" => "",
            "default_language" => "en",
            'employee_create' => '1',
            'payment_reminder' => '1',
            "enable_stripe" => "",
            "enable_paypal" => "",
            "paypal_mode" => "",
            "paypal_client_id" => "",
            "paypal_secret_key" => "",
            "stripe_key" => "",
            "stripe_secret" => "",
            "decimal_number" => "2",
            "tax_type" => "",
            "shipping_display" => "on",
            "journal_prefix" => "#JUR",
            "display_landing_page" => "on",
            "employee_prefix" => "#EMP00",
            'create_user' => '1',
            'award_create' => '1',
            'lead_assign' => '1',
            'deal_assign' => '1',
            'proposal_send' => '1',
            'customer_invoice_send' => '1',
            'bill_payment' => '1',
            'invoice_payment' => '1',
            'bill_resend' => '1',
            'employee_resignation' => '1',
            'resignation_send' => '1',
            'employee_trip' => '1',
            'trip_send' => '1',
            'employee_promotion' => '1',
            'promotion_send' => '1',
            'employee_complaints' => '1',
            'employee_warning' => '1',
            'warning_send' => '1',
            'create_contract' => '1',
            'employee_termination' => '1',
            'termination_send' => '1',
            'leave_status' => '1',
            'employee_transfer' => '1',
            'transfer_send' => '1',
            "bug_prefix" => "#ISSUE",
            'payroll_create' => '1',
            'payslip_send' => '1',
            'title_text' => '',
            'footer_text' => '',
            "company_start_time" => "09:00",
            "company_end_time" => "18:00",
            'gdpr_cookie' => 'off',
            "interval_time" => "",
            "zoom_apikey" => "",
            "zoom_apisecret" => "",
            "slack_webhook" => "",
            "telegram_accestoken" => "",
            "telegram_chatid" => "",
            "enable_signup" => "on",
            'cookie_text' => 'We use cookies to ensure that we give you the best experience on our website. If you continue to use this site we will assume that you are happy with it.',
            "company_logo_light" => "logo-light.png",
            "company_logo_dark" =>  "logo-dark.png",
            "company_favicon" => "favicon.png",
            "cust_theme_bg" => "on",
            "cust_darklayout" => "off",
            "color" => "",
            "SITE_RTL" => "off",
            "purchase_prefix" => "#PUR",
            "purchase_color" => "ffffff",
            "purchase_template" => "template1",
            "pos_prefix" => "#POS",

            "storage_setting" => "local",
            "local_storage_validation" => "",
            "local_storage_max_upload_size" => "",
            "s3_key" => "",
            "s3_secret" => "",
            "s3_region" => "",
            "s3_bucket" => "",
            "s3_url"    => "",
            "s3_endpoint" => "",
            "s3_max_upload_size" => "",
            "s3_storage_validation" => "",
            "wasabi_key" => "",
            "wasabi_secret" => "",
            "wasabi_region" => "",
            "wasabi_bucket" => "",
            "wasabi_url" => "",
            "wasabi_root" => "",
            "wasabi_max_upload_size" => "",
            "wasabi_storage_validation" => "",

            "purchase_logo" => "",
            "proposal_logo" => "",
            "invoice_logo" => "",
            "contract_prefix" => "#CON",



        ];

        foreach ($data as $row) {
            $settings[$row->name] = $row->value;
        }

        return $settings;
    }

    public static function createEmployee($user_id, $created_by)
    {
        $user = User::where('id', $user_id)->first();
        $holidays = CompanyHoliday::where('created_by', Auth::user()->creatorId())->get()->toArray();
        $dayoffs = Dayoff::where('created_by', Auth::user()->creatorId())->get()->toArray();
        $dateNow     = Carbon::now()->format('Y-m-d');
        $dateOneYear = Carbon::now()->addYear()->format('Y-m-d');

        $employee = Employee::create(
            [
                'user_id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'password' => $user->password,
                'employee_id' => self::employeeNumber($created_by),
                'created_by' => $created_by,
                'branch_id' => $user->branch_id,
                'company_doj' => $dateNow,
                'company_doe' =>  $dateOneYear,
            ]
        );
        $dateJoin = Carbon::parse($employee->company_doj);
        $dateEnd  = Carbon::parse($employee->company_doe);

        $diff = $dateJoin->diffInDays($dateEnd);

        $count = 0;
        for ($i = 0; $i <= $diff; $i++) {
            ShiftSchedule::create([
                'employee_id'       => $employee->id,
                'schedule_date'     => $dateJoin,
                'shift_id'          => 1,
                'status'            => 'Approved',
                'created_by'        => $created_by,
                'is_dayoff'         => false,
                'dayoff_type'       => null,
                'description'       => null,
            ]);
            $dateJoin->addDay(1);
        }

        foreach ($holidays as $key => $value) {
            ShiftSchedule::updateShift($value['company_holiday_date'], 'Y-m-d', 'Company Holiday', 'Company Holiday');
        }

        foreach ($dayoffs as $key => $value) {
            ShiftSchedule::updateShift($value['day'], 'l', 'Dayoff', 'Dayoff');
        }
    }

    public static function updateEmployee($user_id, $created_by, $data)
    {
        $employee = Employee::where('user_id', $user_id)->first();

        $employee->update($data);
    }

    public static function insertToRequest($model, $by, $type)
    {
        $allReq = AllRequest::latest()->first();

        if (is_null($allReq)) {
            $allReq = 1;
        } else {
            $allReq = $allReq->id + 1;
        }

        AllRequest::create([
            'request_id'    => $model->id,
            'request_no'    => $allReq,
            'request_for'   => $model->employee->name,
            'request_by'    => $by->name,
            'request_type'  => $type,
            'req_date'      => date("Y-m-d"),
            'created_by'    => $model->created_by,
            'status'        => $model->status,
        ]);
    }

    public static function employeeNumber($user_id)
    {
        $latest = Employee::where('created_by', $user_id)->latest()->first();

        if (!$latest) {
            return 1;
        }

        return $latest->employee_id + 1;
    }

    public static function get_file($path)
    {
        $settings = Utility::getStorageSetting();

        try {
            if ($settings['storage_setting'] == 'wasabi') {
                config(
                    [
                        'filesystems.disks.wasabi.key' => $settings['wasabi_key'],
                        'filesystems.disks.wasabi.secret' => $settings['wasabi_secret'],
                        'filesystems.disks.wasabi.region' => $settings['wasabi_region'],
                        'filesystems.disks.wasabi.bucket' => $settings['wasabi_bucket'],
                        'filesystems.disks.wasabi.endpoint' => 'https://s3.' . $settings['wasabi_region'] . '.wasabisys.com'
                    ]
                );
            } elseif ($settings['storage_setting'] == 's3') {
                config(
                    [
                        'filesystems.disks.s3.key' => $settings['s3_key'],
                        'filesystems.disks.s3.secret' => $settings['s3_secret'],
                        'filesystems.disks.s3.region' => $settings['s3_region'],
                        'filesystems.disks.s3.bucket' => $settings['s3_bucket'],
                        'filesystems.disks.s3.use_path_style_endpoint' => false,
                    ]
                );
            }

            return Storage::disk($settings['storage_setting'])->url($path);
        } catch (\Throwable $th) {
            return '';
        }
    }

    public static function getStorageSetting()
    {
        $data = DB::table('settings');
        $data = $data->where('created_by', '=', 1);
        $data     = $data->get();
        $settings = [
            "storage_setting" => "",
            "local_storage_validation" => "",
            "local_storage_max_upload_size" => "",
            "s3_key" => "",
            "s3_secret" => "",
            "s3_region" => "",
            "s3_bucket" => "",
            "s3_url"    => "",
            "s3_endpoint" => "",
            "s3_max_upload_size" => "",
            "s3_storage_validation" => "",
            "wasabi_key" => "",
            "wasabi_secret" => "",
            "wasabi_region" => "",
            "wasabi_bucket" => "",
            "wasabi_url" => "",
            "wasabi_root" => "",
            "wasabi_max_upload_size" => "",
            "wasabi_storage_validation" => "",
        ];
        foreach ($data as $row) {
            $settings[$row->name] = $row->value;
        }
        return $settings;
    }


    //only employee edit storage setting upload_coustom_file function

    public static function upload_coustom_file($request, $key_name, $name, $path, $data_key, $custom_validation = [])
    {

        try {
            $settings = Utility::getStorageSetting();


            if (!empty($settings['storage_setting'])) {

                if ($settings['storage_setting'] == 'wasabi') {

                    config(
                        [
                            'filesystems.disks.wasabi.key' => $settings['wasabi_key'],
                            'filesystems.disks.wasabi.secret' => $settings['wasabi_secret'],
                            'filesystems.disks.wasabi.region' => $settings['wasabi_region'],
                            'filesystems.disks.wasabi.bucket' => $settings['wasabi_bucket'],
                            'filesystems.disks.wasabi.endpoint' => 'https://s3.' . $settings['wasabi_region'] . '.wasabisys.com'
                        ]
                    );

                    $max_size = !empty($settings['wasabi_max_upload_size']) ? $settings['wasabi_max_upload_size'] : '2048';
                    $mimes =  !empty($settings['wasabi_storage_validation']) ? $settings['wasabi_storage_validation'] : '';
                } else if ($settings['storage_setting'] == 's3') {
                    config(
                        [
                            'filesystems.disks.s3.key' => $settings['s3_key'],
                            'filesystems.disks.s3.secret' => $settings['s3_secret'],
                            'filesystems.disks.s3.region' => $settings['s3_region'],
                            'filesystems.disks.s3.bucket' => $settings['s3_bucket'],
                            'filesystems.disks.s3.use_path_style_endpoint' => false,
                        ]
                    );
                    $max_size = !empty($settings['s3_max_upload_size']) ? $settings['s3_max_upload_size'] : '2048';
                    $mimes =  !empty($settings['s3_storage_validation']) ? $settings['s3_storage_validation'] : '';
                } else {
                    $max_size = !empty($settings['local_storage_max_upload_size']) ? $settings['local_storage_max_upload_size'] : '2048';

                    $mimes =  !empty($settings['local_storage_validation']) ? $settings['local_storage_validation'] : '';
                }


                $file = $request->$key_name;


                if (count($custom_validation) > 0) {
                    $validation = $custom_validation;
                } else {

                    $validation = [
                        'mimes:' . $mimes,
                        'max:' . $max_size,
                    ];
                }

                $validator = Validator::make($request->all(), [
                    $name => $validation
                ]);

                if ($validator->fails()) {
                    $res = [
                        'flag' => 0,
                        'msg' => $validator->messages()->first(),
                    ];
                    return $res;
                } else {

                    $name = $name;

                    if ($settings['storage_setting'] == 'local') {



                        Storage::disk('public')->putFileAs(
                            $path,
                            $request->file($key_name)[$data_key],
                            $name
                        );


                        $path = $name;
                    } else if ($settings['storage_setting'] == 'wasabi') {

                        $path = Storage::disk('wasabi')->putFileAs(
                            $path,
                            $file,
                            $name
                        );

                        // $path = $path.$name;

                    } else if ($settings['storage_setting'] == 's3') {

                        $path = Storage::disk('s3')->putFileAs(
                            $path,
                            $file,
                            $name
                        );
                        // $path = $path.$name;
                        // dd($path);
                    }

                    $res = [
                        'flag' => 1,
                        'msg'  => 'success',
                        'url'  => $path
                    ];
                    return $res;
                }
            } else {
                $res = [
                    'flag' => 0,
                    'msg' => __('Please set proper configuration for storage.'),
                ];
                return $res;
            }
        } catch (\Exception $e) {
            $res = [
                'flag' => 0,
                'msg' => $e->getMessage(),
            ];
            return $res;
        }
    }

    public static function getValByName($key)
    {
        $setting = Utility::settings();
        if (!isset($setting[$key]) || empty($setting[$key])) {
            $setting[$key] = '';
        }

        return $setting[$key];
    }

    public static function getFileType($path)
    {

        $image_extensions = ['jpg', 'jpeg', 'png'];
        $file_document_extensions = ['pdf'];
        $info = pathinfo($path);
        $fileType = $info['extension'];

        if (in_array($fileType, $image_extensions)) {
            return 'image';
        } elseif (in_array($fileType, $file_document_extensions)) {
            return 'file';
        } else {
            return 'invalid extension';
        }
    }

    public static function employeePayslipDetail($employeeId)
    {
        $employee        = Employee::find($employeeId);
        $now = Carbon::now();
        $startDate = Carbon::now(); //returns current day
        $firstDay = $startDate->firstOfMonth()->format('Y-m-d');
        $lastDay = $startDate->lastOfMonth()->format('Y-m-d');

        $earning['salary']      = $employee->salary;
        $earning['allowance']   = AllowanceFinance::where('employee_id', $employeeId)->get();
        $totalAllowance = 0;
        foreach ($earning['allowance'] as $allowance) {
            $totalAllowances  = $allowance->amount;
            $totalAllowance += $totalAllowances;
        }

        $earning['basic_salary']   = Payroll::where('employee_id', $employeeId)->get();

        // $earning['reimburst']   = Reimburst::where('employee_id', $employeeId)->whereYear('created_at', '=', $now->year)
        //     ->whereMonth('created_at', '=', $now->month)->get();
        $earning['reimburst']   = Reimburst::where('employee_id', $employeeId)->get();
        $totalReimburst = 0;
        foreach ($earning['reimburst'] as $reimburst) {
            $totalReimbursts  = $reimburst->amount;
            $totalReimburst += $totalReimbursts;
        }

        $earning['overTime'] = Overtime::where('employee_id', $employeeId)->where('status', 'Approved')->whereBetween('created_at', [$firstDay, $lastDay])->get();
        $totalOvertimeAmountFee = 0;
        foreach ($earning['overTime'] as $overTime) {
            $totalCashInAdvances  = $overTime->amount_fee;
            $totalOvertimeAmountFee += floor($totalCashInAdvances);
        }

        // $deduction['cash_in_advance']   = Cash::where('employee_id', $employeeId)->whereYear('created_at', '=', $now->year)
        //     ->whereMonth('created_at', '=', $now->month)->get();
        $deduction['cash_in_advance']   = Cash::where('employee_id', $employeeId)->get();
        $totalCashInAdvance = 0;
        foreach ($deduction['cash_in_advance'] as $cash_in_advance) {
            $totalCashInAdvances  = $cash_in_advance->amount;
            $totalCashInAdvance += $totalCashInAdvances;
        }

        $deduction['denda']   = AttendanceEmployee::where('employee_id', $employeeId)->where('denda', '!=', null)->orWhere('denda', '>', 0)->whereBetween('date', [$firstDay, $lastDay])->get();
        $totalDenda = 0;
        foreach ($deduction['denda'] as $denda) {
            $totalDendas  = $denda->denda;
            $totalDenda += $totalDendas;
        }

        $bpjs_tk = Utility::where('name', 'bpjs_tk')->first();
        $bpjs_tk_val = null;
        $totalBpjsTkAmount = 0;
        if (!is_null($bpjs_tk)) {
            $bpjs_tk_val = json_decode($bpjs_tk->value, true);
            $deduction['bpjs_kesehatan']   = $bpjs_tk_val;
            if ($deduction['bpjs_kesehatan']['type'] == 'Fixed') {
                $totalVal  = $deduction['bpjs_kesehatan']['value'];
            } else {
                $totalVal  = (int)$deduction['bpjs_kesehatan']['value'] * $employee->salary / 100;
            }
            $totalBpjsTkAmount += $totalVal;
        }

        //PPH21
        $pph21 = Utility::where('name', 'pph21')->first();
        $pph21_val = null;
        $totalPph21Amount = 0;
        $countPayslip =  count($employee->payslips);

        if (!is_null($pph21)) {
            $pph21_val = json_decode($pph21->value, true);
            $deduction['pph21'] = $pph21_val;
            $annualGrossIncome = $employee->salary * 12;
            if ($annualGrossIncome <= $pph21_val[0]['income']) {
                $totalPph21Amount = $annualGrossIncome * $pph21_val[0]['percentage'] / 100;
            } elseif (isset($pph21_val[1]['income'])) {
                if ($annualGrossIncome > $pph21_val[0]['income'] && $annualGrossIncome <= $pph21_val[1]['income']) {
                    $totalPph21Amount = $annualGrossIncome * $pph21_val[0]['percentage'] / 100;
                }
            } elseif (isset($pph21_val[2]['income'])) {
                if ($annualGrossIncome > $pph21_val[1]['income'] && $annualGrossIncome <= $pph21_val[2]['income']) {
                    $totalPph21Amount = $annualGrossIncome * $pph21_val[0]['percentage'] / 100;
                }
            } elseif (isset($pph21_val[3]['income'])) {
                if ($annualGrossIncome > $pph21_val[2]['income'] && $annualGrossIncome <= $pph21_val[3]['income']) {
                    $totalPph21Amount = $annualGrossIncome * $pph21_val[0]['percentage'] / 100;
                }
            } elseif (isset($pph21_val[4]['income'])) {
                if ($annualGrossIncome > $pph21_val[4]['income']) {
                    $totalPph21Amount = $annualGrossIncome * $pph21_val[0]['percentage'] / 100;
                }
            } else {
                toast('PPH21 setting is not correct yet.', 'warning');
            }
            $totalPph21Amount = $totalPph21Amount > 0 ? $totalPph21Amount / 12 : 0;
        }
        $deduction['totalPph21Amount'] = $totalPph21Amount;

        $deduction['loan']   = Loan::where('employee_id', $employeeId)->get();
        $totalLoan = 0;
        foreach ($deduction['loan'] as $loan) {
            $totalReimbursts  = $loan->amount;
            $totalLoan += $totalReimbursts;
        }

        $set_bpjstk = SetBpjsTK::where('employee_id', $employeeId)->get();
        $totalJhtAmount = 0;
        $totalJpAmount = 0;

        foreach ($set_bpjstk as $key => $value) {
            $decodeDataBpjstk = json_decode($value->bpjstk_name, true);
            foreach ($decodeDataBpjstk as $key => $value) {
                if ($value == 'JHT') {
                    $jht = Utility::where('name', 'jht')->first();
                    $jht_val = null;
                    if (!is_null($jht)) {
                        $jht_val = json_decode($jht->value, true);
                        $deduction['jht']   = $jht_val;
                        // $totalVal  = (int)$deduction['jht']['value'] * $employee->salary / 100;
                        $totalVal  = 2 * $employee->salary / 100;
                        $totalJhtAmount += $totalVal;
                    }
                } elseif ($value == 'JP') {
                    $jp = Utility::where('name', 'jp')->first();
                    $jp_val = null;
                    if (!is_null($jp)) {
                        $jp_val = json_decode($jp->value, true);
                        $deduction['jp']   = $jp_val;
                        // $totalVal  = (int)$deduction['jp']['value'] * $employee->salary / 100;
                        $totalVal  = 1 * $employee->salary / 100;
                        $totalJpAmount += $totalVal;
                    }
                }
            }
        }

        //total bpjstk
        $totalBpjsTk = $totalJhtAmount + $totalJpAmount;
        $deduction['totalBpjsTk'] = $totalBpjsTk;


        $payslip['earning']        = $earning;
        $payslip['totalEarning']   = is_null($employee->salary) ? 0 : $employee->salary  + $totalAllowance + $totalReimburst + $totalOvertimeAmountFee;
        $payslip['deduction']      = $deduction;
        $payslip['totalDeduction'] = $totalCashInAdvance + $totalBpjsTkAmount + $totalDenda + $totalPph21Amount + $totalLoan + $totalBpjsTk;

        return $payslip;
    }

    public static function nationalHoliday()
    {
        $nationalDaysFetch = json_decode(file_get_contents("https://raw.githubusercontent.com/guangrei/Json-Indonesia-holidays/master/calendar.json"), true);


        return $nationalDaysFetch;
    }
}
