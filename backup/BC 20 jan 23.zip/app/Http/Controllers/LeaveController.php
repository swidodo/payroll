<?php

namespace App\Http\Controllers;

use App\Models\AttendanceEmployee;
use App\Models\Employee;
use App\Models\Leave;
use App\Models\LeaveType;
use App\Models\Overtime;
use App\Models\Utility;
use Carbon\Carbon;
use DateTime;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class LeaveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Auth::user()->can('manage leave')) {
            if (Auth::user()->type != 'company') {
                $user     = Auth::user();
                $employee = Employee::where('user_id', '=', $user->id)->get();
                $leaves  = Leave::where('employee_id', '=', $user->employee->id)->get();
                $leaveType = LeaveType::where('created_by', '=', Auth::user()->creatorId())->get();

                return view('pages.contents.time-management.leaves.index', compact('leaves', 'employee', 'leaveType'));
            } else {
                $leaves = Leave::where('created_by', '=', Auth::user()->creatorId())->get();
                $employee  = Employee::where('created_by', '=', Auth::user()->creatorId())->get();
                $leaveType = LeaveType::where('created_by', '=', Auth::user()->creatorId())->get();

                return view('pages.contents.time-management.leaves.index', compact('leaves', 'employee', 'leaveType'));
            }
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (Auth::user()->can('create leave')) {
            $validator = Validator::make(
                $request->all(),
                [
                    'leave_type_id' => 'required',
                    'employee_id' => 'required',
                    'start_date' => 'required',
                    'end_date' => 'required',
                    // 'leave_reason' => 'required',
                    //    'remark' => 'required',
                ]
            );

            if ($validator->fails()) {
                return redirect()->back()->with('errors', $validator->messages());
            }
            try {
                DB::beginTransaction();
                $startDate = new DateTime($request->start_date);
                $endDate   = new DateTime($request->end_date);
                $total_leave_days = !empty($startDate->diff($endDate)) && $startDate < $endDate ? $startDate->diff($endDate)->days : 0;
                $employee = Employee::where('user_id', '=', Auth::user()->id)->first();
                $startDateCarbon = Carbon::parse($request->start_date);

                $leave    = new Leave();
                if (Auth::user()->type == "employee") {
                    $leave->employee_id = $employee->id;
                } else {
                    $leave->employee_id = $request->employee_id;
                }

                $filePath = '';
                if ($request->file('attachment_request')) {
                    $fileName = time() . '_' . $request->file('attachment_request')->getClientOriginalName();
                    $store = $request->file('attachment_request')->storeAs('public', $fileName);
                    $pathFile = 'storage/' . $fileName ?? null;
                    $leave->attachment_request_path =  $pathFile;
                }

                $leave->leave_type_id    = $request->leave_type_id;
                $leave->applied_on       = date('Y-m-d');
                $leave->start_date       = $request->start_date;
                $leave->end_date         = $request->end_date;
                $leave->total_leave_days = $total_leave_days;
                $leave->leave_reason     = $request->leave_reason;
                // $leave->remark           = $request->remark;
                $leave->status           = Auth::user()->type == "company" ? 'Approved' : 'Pending';
                $leave->created_by       = Auth::user()->creatorId();
                $leave->save();

                if (Auth::user()->type == "company") {
                    if ($leave->total_leave_day > 1) {
                        for ($i = 0; $i < $leave->total_leave_day; $i++) {
                            // if (strtolower($leave->leave_type->title) == 'sick' || strtolower($leave->leave_type->title) == 'sakit') {
                            //     if (!is_null($leave->attachment_request_path)) {
                            //         //insert to attendance employee if user type if company
                            //         if (Auth::user()->type == "company") {
                            //             $employeeAttendance              = new AttendanceEmployee();
                            //             $employeeAttendance->employee_id   = $leave->employee_id;
                            //             $employeeAttendance->date          = $startDateCarbon->addDay(1)->format('Y-m-d');
                            //             $employeeAttendance->status        = 'Sick With Letter';
                            //             $employeeAttendance->clock_in      = '00:00:00';
                            //             $employeeAttendance->clock_out     = '00:00:00';
                            //             $employeeAttendance->late          = '00:00:00';
                            //             $employeeAttendance->early_leaving = '00:00:00';
                            //             $employeeAttendance->overtime      = '00:00:00';
                            //             $employeeAttendance->total_rest    = '00:00:00';
                            //             $employeeAttendance->created_by       = Auth::user()->creatorId();
                            //             $employeeAttendance->save();
                            //         }
                            //     } else {
                            //         if (Auth::user()->type == "company") {
                            //             $employeeAttendance              = new AttendanceEmployee();
                            //             $employeeAttendance->employee_id   = $leave->employee_id;
                            //             $employeeAttendance->date          = $startDateCarbon->addDay(1)->format('Y-m-d');
                            //             $employeeAttendance->status        = 'Sick Without Letter';
                            //             $employeeAttendance->clock_in      = '00:00:00';
                            //             $employeeAttendance->clock_out     = '00:00:00';
                            //             $employeeAttendance->late          = '00:00:00';
                            //             $employeeAttendance->early_leaving = '00:00:00';
                            //             $employeeAttendance->overtime      = '00:00:00';
                            //             $employeeAttendance->total_rest    = '00:00:00';
                            //             $employeeAttendance->created_by       = Auth::user()->creatorId();
                            //             $employeeAttendance->save();
                            //         }
                            //     }
                            // } elseif (strtolower($leave->leave_type->title) == 'permit' || strtolower($leave->leave_type->title) == 'izin') {
                            //     if (Auth::user()->type == "company") {
                            //         $employeeAttendance              = new AttendanceEmployee();
                            //         $employeeAttendance->employee_id   = $leave->employee_id;
                            //         $employeeAttendance->date          = $startDateCarbon->addDay(1)->format('Y-m-d');
                            //         $employeeAttendance->status        = 'Permit';
                            //         $employeeAttendance->clock_in      = '00:00:00';
                            //         $employeeAttendance->clock_out     = '00:00:00';
                            //         $employeeAttendance->late          = '00:00:00';
                            //         $employeeAttendance->early_leaving = '00:00:00';
                            //         $employeeAttendance->overtime      = '00:00:00';
                            //         $employeeAttendance->total_rest    = '00:00:00';
                            //         $employeeAttendance->created_by       = Auth::user()->creatorId();
                            //         $employeeAttendance->save();
                            //     }
                            // } elseif (strtolower($leave->leave_type->title) == 'leave' || strtolower($leave->leave_type->title) == 'cuti') {
                            //     if (Auth::user()->type == "company") {
                            //         $employeeAttendance              = new AttendanceEmployee();
                            //         $employeeAttendance->employee_id   = $leave->employee_id;
                            //         $employeeAttendance->date          = $startDateCarbon->addDay(1)->format('Y-m-d');
                            //         $employeeAttendance->status        = 'Leave';
                            //         $employeeAttendance->clock_in      = '00:00:00';
                            //         $employeeAttendance->clock_out     = '00:00:00';
                            //         $employeeAttendance->late          = '00:00:00';
                            //         $employeeAttendance->early_leaving = '00:00:00';
                            //         $employeeAttendance->overtime      = '00:00:00';
                            //         $employeeAttendance->total_rest    = '00:00:00';
                            //         $employeeAttendance->created_by       = Auth::user()->creatorId();
                            //         $employeeAttendance->save();
                            //     }
                            // }


                            AttendanceEmployee::insertToAttendanceEmployeeLeave($leave, $leave->leave_type->title, $leave->attachment_request_path, $startDateCarbon);
                            //add day to date
                            $startDateCarbon->addDay(1);
                        }
                    } else {
                        AttendanceEmployee::insertToAttendanceEmployeeLeave($leave, $leave->leave_type->title, $leave->attachment_request_path, $startDateCarbon);
                    }
                }

                if (Auth::user()->type != "company" && Auth::user()->type != "client") {
                    Utility::insertToRequest($leave, Auth::user(), 'Leave');
                }

                DB::commit();
                toast('Leave successfully created.', 'success');
                return redirect()->route('leaves.index');
            } catch (Exception $e) {
                DB::rollBack();
                toast('Something went wrong.', 'error');
                return redirect()->back();
            }
        } else {
            toast('Permission denied.', 'error');
            toast('Permission denied.', 'error');
            return redirect()->back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $leave = Leave::find($id);
        $fileType = null;

        if (!is_null($leave->attachment_reject)) {
            $fileType = Utility::getFileType($leave->attachment_reject);
        }

        return view('pages.contents.time-management.leaves.detail-rejected', compact('leave', 'fileType'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $leave = Leave::find($id);
        if (Auth::user()->can('edit leave')) {
            if ($leave->created_by == Auth::user()->creatorId()) {
                $employee  = Employee::where('created_by', '=', Auth::user()->creatorId())->where('id', $leave->employee_id)->first();
                $leavetypes = LeaveType::where('created_by', '=', Auth::user()->creatorId())->get();

                return response()->json([$employee, $leavetypes, $leave]);
                // return view('leaves.edit', compact('leave', 'employees', 'leavetypes'));
            } else {
                return response()->json(['error' => 'Permission denied.'], 401);
            }
        } else {
            return response()->json(['error' => 'Permission denied.'], 401);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (Auth::user()->can('edit leave')) {
            $validator = Validator::make(
                $request->all(),
                [
                    'leave_type_id' => 'required',
                    'employee_id' => 'required',
                    'start_date' => 'required',
                    'end_date' => 'required',
                    'leave_reason' => 'required',
                    //    'remark' => 'required',
                ]
            );


            if ($validator->fails()) {
                return redirect()->back()->with('errors', $validator->messages());
            }

            $startDate = new DateTime($request->start_date);
            $endDate   = new DateTime($request->end_date);
            $total_leave_days = !empty($startDate->diff($endDate)) && $startDate < $endDate ? $startDate->diff($endDate)->days : 0;
            $startDateCarbon = Carbon::parse($request->start_date);


            try {
                DB::beginTransaction();
                $leave    =  Leave::find($id);

                $filePath = '';
                if ($request->file('attachment_reject')) {
                    $fileName = time() . '_' . $request->file('attachment_reject')->getClientOriginalName();
                    $filePath = $request->file('attachment_reject')->storeAs('public', $fileName);
                    $leave->attachment_reject =  'storage/' . $fileName ?? null;
                }


                $leave->employee_id     = $request->employee_id;
                $leave->leave_type_id    = $request->leave_type_id;
                $leave->applied_on       = date('Y-m-d');
                $leave->start_date       = $request->start_date;
                $leave->end_date         = $request->end_date;
                $leave->total_leave_days = $total_leave_days;
                $leave->leave_reason     = $request->leave_reason;
                // $leave->remark           = $request->remark;
                $leave->status           =  $request->status ?? 'Pending';
                $leave->rejected_reason  =  $request->rejected_reason ?? null;
                $leave->created_by       = Auth::user()->creatorId();
                $leave->save();

                if ($leave->status == 'Approved' && Auth::user()->type == "employee" && Auth::user()->type != "company") {
                    if ($leave->total_leave_day > 1) {
                        for ($i = 0; $i < $leave->total_leave_day; $i++) {
                            AttendanceEmployee::insertToAttendanceEmployeeLeave($leave, $leave->leave_type->title, $leave->attachment_request_path, $startDateCarbon);
                            //add day to date
                            $startDateCarbon->addDay(1);
                        }
                    } else {
                        AttendanceEmployee::insertToAttendanceEmployeeLeave($leave, $leave->leave_type->title, $leave->attachment_request_path, $startDateCarbon);
                    }
                }

                DB::commit();
                toast('Leave successfully updated.', 'success');
                return redirect()->route('leaves.index');
            } catch (Exception $e) {
                DB::rollBack();
                toast('Something went wrong.', 'error');
                return redirect()->back();
            }
        } else {
            toast('Permission denied.', 'error');
            toast('Permission denied.', 'error');
            return redirect()->back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $leave = Leave::find($id);
        if (Auth::user()->can('delete leave')) {
            if ($leave->created_by == Auth::user()->creatorId()) {
                if ($leave->attachment_reject != null) {
                    $fileNameAttReject = explode('/', $leave->attachment_reject);
                    if (Storage::exists('public/' . $fileNameAttReject[1])) {
                        Storage::delete('public/' . $fileNameAttReject[1]);
                    }
                }
                if ($leave->attachment_request_path != null) {
                    $fileNameAttReject = explode('/', $leave->attachment_request_path);
                    if (Storage::exists('public/' . $fileNameAttReject[1])) {
                        Storage::delete('public/' . $fileNameAttReject[1]);
                    }
                }
                $leave->delete();

                toast('Leave successfully deleted.', 'success');
                return redirect()->route('leaves.index');
            } else {
                toast('Permission denied.', 'error');
                toast('Permission denied.', 'error');
                return redirect()->back();
            }
        } else {
            toast('Permission denied.', 'error');
            toast('Permission denied.', 'error');
            return redirect()->back();
        }
    }
}
