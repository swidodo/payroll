<?php

namespace App\Http\Controllers;

use App\Models\AttendanceEmployee;
use App\Models\Employee;
use App\Models\ShiftSchedule;
use App\Models\Timesheet;
use App\Models\Utility;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public  function index()
    {
        if (Auth::user()->type == 'company') {

            return view('pages.contents.dashboard.dashboard-company');
        } else {
            $employee = Employee::where('user_id', Auth::user()->id)->first();
            $attendanceStatus = $employee->present_status($employee->id, date('Y-m-d'));
            $attendanceEmployee = AttendanceEmployee::where('employee_id', $employee->id)->orderBy('id', 'desc')->first();
            $shiftSchedule = ShiftSchedule::where('employee_id', Auth::user()->employee->id)->where('created_by', '=', Auth::user()->creatorId())->where('schedule_date', date('Y-m-d'))->first();
            $timesheet = Timesheet::where('employee_id', Auth::user()->employee->id)->where('created_by', '=', Auth::user()->creatorId())->where('start_date', '<=', date('Y-m-d'))->where('end_date', '>=', date('Y-m-d'))->first();

            return view('pages.contents.dashboard.dashboard', compact('employee', 'attendanceStatus', 'attendanceEmployee', 'shiftSchedule', 'timesheet'));
        }
    }
}
