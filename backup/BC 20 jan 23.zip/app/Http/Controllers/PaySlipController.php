<?php

namespace App\Http\Controllers;

use App\Models\AllowanceFinance;
use App\Models\AttendanceEmployee;
use App\Models\Employee;
use App\Models\Payroll;
use App\Models\PaySlip;
use App\Models\ShiftSchedule;
use App\Models\Utility;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
// use Barryvdh\DomPDF\Facade\Pdf;
use Exception;
use Illuminate\Support\Facades\Storage;
use PDF;

class PaySlipController extends Controller
{
    public function index()
    {
        if (Auth::user()->can('manage payslip')) {
            if (Auth::user()->type != 'company') {
                $user     = Auth::user();
                $employees = Employee::where('user_id', '=', $user->id)->get();
                if (count($employees) > 0) {
                    $net_salary = 0;
                    foreach ($employees as $key => $value) {
                        if (!is_null($value->salary)) {
                            $payslipDetail = Utility::employeePayslipDetail($value->id);
                            $value->net_salary = $payslipDetail['totalEarning'] - $payslipDetail['totalDeduction'];
                            $value->save();
                        }
                    }
                }

                return view('pages.contents.payroll.payslip.index', compact('employees'));
            } else {
                $employees = Employee::where(
                    [
                        'created_by' => Auth::user()->creatorId(),
                    ]
                )->get();

                if (count($employees) > 0) {
                    $net_salary = 0;
                    foreach ($employees as $key => $value) {
                        if (!is_null($value->salary)) {
                            $payslipDetail = Utility::employeePayslipDetail($value->id);
                            $value->net_salary = $payslipDetail['totalEarning'] - $payslipDetail['totalDeduction'];
                            $value->save();
                        }
                    }
                }
                return view('pages.contents.payroll.payslip.index', compact('employees'));
            }
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back();
        }
    }

    public function show($id)
    {
        $employee = Employee::find($id);

        if (is_null($employee) || empty($employee)) {
            toast('Employee not found', 'warning');
            return redirect()->route('payslips.index');
        }

        $paySlips = PaySlip::where('created_by', Auth::user()->creatorId())->where('employee_id', $employee->id)->get();
        return view('pages.contents.payroll.payslip.detail', compact('paySlips'));
    }

    public function generateSlip(Employee $employee)
    {
        if (Auth::user()->can('generate payslip')) {
            try {
                DB::beginTransaction();
                $paySlip = PaySlip::where('created_by', Auth::user()->creatorId())->where('salary_month', date('Y-m'))->first();
                $date_now = Carbon::now();

                // if (!is_null($paySlip)) {
                //     toast('Payslip for this month has been made.', 'warning');
                //     return redirect()->route('payslips.index');
                // }

                if ($employee->salary < 0 || is_null($employee->salary)) {
                    toast('Please set employee salary.', 'warning');
                    return redirect()->route('payslips.index');
                }

                $payslipDetail = Utility::employeePayslipDetail($employee->id);

                $now = Carbon::now();
                $formate_month_year = $now->firstOfMonth()->format('Y-m');

                $payslipEmployee                       = new PaySlip();
                $payslipEmployee->employee_id          = $employee->id;
                $payslipEmployee->net_payble           = $payslipDetail['totalEarning'] - $payslipDetail['totalDeduction'];
                $payslipEmployee->salary_month         = $formate_month_year;
                $payslipEmployee->status               = 1;
                $payslipEmployee->basic_salary         = json_encode($payslipDetail['earning']['basic_salary']);
                $payslipEmployee->salary               = $employee->salary;
                $payslipEmployee->allowance            = json_encode($payslipDetail['earning']['allowance']);
                $payslipEmployee->reimburst            = json_encode($payslipDetail['earning']['reimburst']);
                $payslipEmployee->cash_in_advance      = json_encode($payslipDetail['deduction']['cash_in_advance']);
                $payslipEmployee->denda                = json_encode($payslipDetail['deduction']['denda']);
                $payslipEmployee->loan                = json_encode($payslipDetail['deduction']['loan']);
                $payslipEmployee->bpjs_kesehatan       = isset($payslipDetail['deduction']['bpjs_kesehatan']) ? json_encode($payslipDetail['deduction']['bpjs_kesehatan']) : null;
                $payslipEmployee->pph21                = isset($payslipDetail['deduction']['pph21']) ? json_encode($payslipDetail['deduction']['pph21']) : null;
                $payslipEmployee->overtime             = json_encode($payslipDetail['earning']['overTime']);
                $payslipEmployee->created_by           = Auth::user()->creatorId();

                //earning
                $payslipAllowance = json_decode($payslipEmployee->allowance, true);
                $payslipReimburst = json_decode($payslipEmployee->reimburst, true);
                $payslipOvertime = json_decode($payslipEmployee->overtime, true);
                $payslipBasicSalary = json_decode($payslipEmployee->basic_salary, true);

                //deduction
                $payslipCashInAdvance = json_decode($payslipEmployee->cash_in_advance, true);
                $payslipLoan = json_decode($payslipEmployee->loan, true);
                $payslipDenda = json_decode($payslipEmployee->denda, true);
                $payslipBpjsK = json_decode($payslipEmployee->bpjs_kesehatan, true);
                $payslipPph21 = $payslipDetail['deduction']['totalPph21Amount'];
                $payslipBpjsTk = $payslipDetail['deduction']['totalBpjsTk'];

                $start_date = $date_now->startOfMonth()->toDateString();
                $end_date   = $date_now->endOfMonth()->toDateString();

                //attendance summary
                $scheduleWorkDay    = ShiftSchedule::where('employee_id', $employee->id)
                    ->whereBetween('schedule_date', [$start_date, $end_date])
                    ->where('is_dayoff', false)
                    ->get()
                    ->count();
                $dayoffs    = ShiftSchedule::where('employee_id', $employee->id)
                    ->whereBetween('schedule_date', [$start_date, $end_date])
                    ->where('is_dayoff', true)->where('dayoff_type', 'Dayoff')
                    ->get()
                    ->count();
                $actualWorkDay      = AttendanceEmployee::where('employee_id', $employee->id)
                    ->whereBetween('date', [$start_date, $end_date])
                    ->where('status', 'Present')
                    ->where('clock_in', '!=', '00:00:00')
                    ->where('clock_out', '!=', '00:00:00')
                    ->get()
                    ->count();
                $attendanceSts     = AttendanceEmployee::where('employee_id', $employee->id)
                    ->whereBetween('date', [$start_date, $end_date])
                    ->where('status', '!=', 'Present')
                    ->where('status', '!=', 'Leave')
                    ->where('status', '!=', 'Permit')
                    ->where('status', '!=', 'Sick With Letter')
                    ->get()
                    ->count();
                $attendanceSds     = AttendanceEmployee::where('employee_id', $employee->id)
                    ->whereBetween('date', [$start_date, $end_date])
                    ->where('status', 'Sick With Letter')
                    ->get()
                    ->count();
                $attendanceIzn     = AttendanceEmployee::where('employee_id', $employee->id)
                    ->whereBetween('date', [$start_date, $end_date])
                    ->where('status', 'Permit')
                    ->get()
                    ->count();
                $attendanceCt     = AttendanceEmployee::where('employee_id', $employee->id)
                    ->whereBetween('date', [$start_date, $end_date])
                    ->where('status', 'Leave')
                    ->get()
                    ->count();
                $nationalHolidays    = ShiftSchedule::where('employee_id', $employee->id)
                    ->whereBetween('schedule_date', [$start_date, $end_date])
                    ->where('is_dayoff', true)->where('dayoff_type', 'National Holiday')
                    ->get()
                    ->count();
                $companyHolidays    = ShiftSchedule::where('employee_id', $employee->id)
                    ->whereBetween('schedule_date', [$start_date, $end_date])
                    ->where('is_dayoff', true)
                    ->where('dayoff_type', 'Company Holiday')
                    ->get()->count();
                $shiftSchedules    = ShiftSchedule::where('employee_id', $employee->id)
                    ->whereBetween('schedule_date', [$start_date, $end_date])
                    ->where('is_dayoff', false)
                    ->get();
                $employeeAtt        = AttendanceEmployee::where('employee_id', $employee->id)
                    ->whereBetween('date', [$start_date, $end_date])
                    ->get();

                $attendanceSummary = [
                    'actual_work_day'   => $actualWorkDay,
                    'schedule_work_day' => $scheduleWorkDay,
                    'dayoff'            => $dayoffs,
                    'national_holiday'  => $nationalHolidays,
                    'company_holiday'  => $companyHolidays,
                ];

                $timeOffCodes = [
                    'H' => $actualWorkDay,
                    'STS' => $attendanceSts,
                    'SDS' => $attendanceSds,
                    'IZN' => $attendanceIzn,
                    'CT' => $attendanceCt,
                ];

                $pdf = PDF::loadView('pages.contents.payroll.payslip.pdf', compact('payslipEmployee', 'employee', 'payslipAllowance', 'payslipReimburst', 'payslipOvertime', 'payslipBasicSalary', 'payslipCashInAdvance', 'payslipDenda', 'payslipBpjsK', 'payslipDetail', 'payslipPph21', 'payslipLoan', 'payslipBpjsTk', 'attendanceSummary', 'timeOffCodes'));

                $pdfToStorage = Storage::disk('public')->put('Payslip ' . $payslipEmployee->salary_month . '.pdf', $pdf->output());
                // dd($pdfToStorage);
                if ($pdfToStorage) {
                    $payslipEmployee->pdf_filename           = 'Payslip ' . $payslipEmployee->salary_month . '.pdf';
                }

                $payslipEmployee->save();

                DB::commit();
                return $pdf->download('Payslip ' . $payslipEmployee->salary_month . '.pdf');
            } catch (Exception $e) {
                DB::rollBack();
                toast('Something went wrong.' . $e, 'error');
                dd($e);
                return redirect()->back();
            }
        }
    }

    public function downloadPDF(PaySlip $payslipEmployee)
    {
        return response()->download(storage_path('app/public/' . $payslipEmployee->pdf_filename));
    }
}
