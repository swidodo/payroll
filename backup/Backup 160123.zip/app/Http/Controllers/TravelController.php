<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Travel;
use App\Models\Utility;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator as FacadesValidator;

use function GuzzleHttp\Promise\all;

class TravelController extends Controller
{
    public function index()
    {
        if (Auth::user()->can('manage on duty')) {
            if (Auth::user()->type == 'employee') {
                $emp     = Employee::where('user_id', '=', Auth::user()->id)->first();
                $travels = Travel::where('created_by', '=', Auth::user()->creatorId())->where('employee_id', '=', $emp->id)->get();
                $employee     = Employee::where('created_by', '=', Auth::user()->creatorId())->get();
            } else {
                $travels = Travel::where('created_by', '=', Auth::user()->creatorId())->get();
                $employee     = Employee::where('created_by', '=', Auth::user()->creatorId())->get();
            }

            return view('pages.contents.travel.index', compact('travels', 'employee'));
        } else {
            return redirect()->back()->with('error', 'Permission denied.');
        }
    }

    public function store(Request $request)
    {
        if (Auth::user()->can('create on duty')) {
            $validator = FacadesValidator::make(
                $request->all(),
                [
                    'employee_id' => 'required',
                    'start_date' => 'required',
                    'end_date' => 'required',
                    'purpose_of_visit' => 'required',
                    'place_of_visit' => 'required',
                ]
            );

            if ($validator->fails()) {
                return redirect()->back()->with('errors', $validator->messages());
            }

            try {
                DB::beginTransaction();

                if (Auth::user()->type == 'company') {
                    $travel                   = new Travel();
                    $travel->employee_id      = $request->employee_id;
                    $travel->start_date       = $request->start_date;
                    $travel->end_date         = $request->end_date;
                    $travel->purpose_of_visit = $request->purpose_of_visit;
                    $travel->place_of_visit   = $request->place_of_visit;
                    $travel->description      = $request->description;
                    // $travel->status           = 'Pending';
                    $travel->status           = 'Approved';
                    $travel->created_by       = Auth::user()->creatorId();
                    $travel->save();
                } else {
                    $travel                   = new Travel();
                    $travel->employee_id      = $request->employee_id;
                    $travel->start_date       = $request->start_date;
                    $travel->end_date         = $request->end_date;
                    $travel->purpose_of_visit = $request->purpose_of_visit;
                    $travel->place_of_visit   = $request->place_of_visit;
                    $travel->description      = $request->description;
                    $travel->status           = 'Pending';
                    $travel->created_by       = Auth::user()->creatorId();
                    $travel->save();
                }
                Utility::insertToRequest($travel, Auth::user(), 'On Duty');



                $setings = Utility::settings();
                if ($setings['trip_send'] == 1) {
                    $employee      = Employee::find($travel->employee_id);

                    $tripArr = [
                        'trip_name' => $employee->name,
                        'purpose_of_visit' => $travel->purpose_of_visit,
                        'start_date'  => $travel->start_date,
                        'end_date'  => $travel->end_date,
                        'place_of_visit' => $travel->place_of_visit,
                        'trip_description' => $travel->description,
                    ];

                    // $resp = Utility::sendEmailTemplate('trip_send', [$employee->id => $employee->email], $tripArr);

                    // return redirect()->route('travel.index')->with('success', __('Travel  successfully created.') . ((!empty($resp) && $resp['is_success'] == false && !empty($resp['error'])) ? '<br> <span class="text-danger">' . $resp['error'] . '</span>' : ''));
                }
                DB::commit();

                toast('On Duty successfully created.', 'success');
                return redirect()->route('travels.index');
            } catch (Exception $e) {
                DB::rollBack();
                toast('Something went wrong.', 'error');
                return redirect()->back();
            }
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back()->with('error', 'Permission denied.');
        }
    }

    public function show($id)
    {
        $travel = Travel::find($id);
        $fileType = null;

        if (!is_null($travel->attachment_reject)) {
            $fileType = Utility::getFileType($travel->attachment_reject);
        }

        return view('pages.contents.travel.detail-rejected', compact('travel', 'fileType'));
    }

    public function edit(Travel $travel)
    {
        if (Auth::user()->can('edit on duty')) {
            // $employees = Employee::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
            if ($travel->created_by == Auth::user()->creatorId()) {
                return response()->json($travel);
            } else {
                return response()->json(['error' => 'Permission denied.'], 401);
            }
        } else {
            return response()->json(['error' => 'Permission denied.'], 401);
        }
    }

    public function update(Request $request, Travel $travel)
    {
        if (Auth::user()->can('edit on duty')) {
            if ($travel->created_by == Auth::user()->creatorId()) {

                $validator = FacadesValidator::make(
                    $request->all(),
                    [
                        'employee_id' => 'required',
                        'start_date' => 'required',
                        'end_date' => 'required',
                        'purpose_of_visit' => 'required',
                        'place_of_visit' => 'required',
                    ]
                );
                if ($validator->fails()) {
                    $messages = $validator->getMessageBag();

                    return redirect()->back()->with('error', $messages->first());
                }

                try {
                    DB::beginTransaction();

                    if ($request->file('attachment_reject')) {
                        $fileName = time() . '_' . $request->file('attachment_reject')->getClientOriginalName();
                        $filePath = $request->file('attachment_reject')->storeAs('public', $fileName);
                        $travel->attachment_reject =  'storage/' . $fileName ?? null;
                    }

                    $travel->employee_id      = $request->employee_id;
                    $travel->start_date       = $request->start_date;
                    $travel->end_date         = $request->end_date;
                    $travel->purpose_of_visit = $request->purpose_of_visit;
                    $travel->place_of_visit   = $request->place_of_visit;
                    $travel->description      = $request->description;
                    $travel->status           = $request->status;
                    $travel->rejected_reason  =  $request->rejected_reason ?? null;
                    $travel->save();

                    DB::commit();

                    toast('On Duty successfully updated.', 'success');
                    return redirect()->route('travels.index');
                } catch (Exception $e) {
                    DB::rollBack();
                    toast('Something went wrong.', 'error');
                    return redirect()->back();
                }
            } else {
                toast('Permission denied.', 'error');
                return redirect()->back()->with('error', 'Permission denied.');
            }
        } else {
            toast('Permission denied.', 'error');
            return redirect()->back()->with('error', 'Permission denied.');
        }
    }

    public function destroy(Travel $travel)
    {
        if (Auth::user()->can('delete on duty')) {
            if ($travel->created_by == Auth::user()->creatorId()) {
                if ($travel->attachment_reject != null) {
                    $fileNameAttReject = explode('/', $travel->attachment_reject);
                    if (Storage::exists('public/' . $fileNameAttReject[1])) {
                        Storage::delete('public/' . $fileNameAttReject[1]);
                    }
                }

                $travel->delete();
                toast('On Duty successfully deleted.', 'success');
                return redirect()->route('travels.index');
            } else {
                toast('Permission denied.', 'error');

                return redirect()->back()->with('error', 'Permission denied.');
            }
        } else {
            toast('Permission denied.', 'error');

            return redirect()->back()->with('error', 'Permission denied.');
        }
    }
}
