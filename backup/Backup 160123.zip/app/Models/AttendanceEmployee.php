<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AttendanceEmployee extends Model
{
    use HasFactory;

    protected $fillable = [
        'employee_id',
        'date',
        'status',
        'clock_in',
        'clock_out',
        'late',
        'denda',
        'early_leaving',
        'overtime',
        'total_rest',
        'created_by',
    ];

    // public function employees()
    // {
    //     return $this->hasOne(Employee::class, 'user_id', 'employee_id');
    // }

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id');
    }

    public function shift()
    {
        return $this->belongsTo(ShiftSchedule::class, 'date', 'schedule_date');
    }

    public static function getLateClockIn($clock_in)
    {
        $startTime = Utility::getValByName('company_start_time');

        $in = date("H:i:s", strtotime($clock_in));
        $totalLateSeconds = strtotime($in) - strtotime($startTime);

        // late
        $hours = floor($totalLateSeconds / 3600);
        $mins  = floor($totalLateSeconds / 60 % 60);
        $secs  = floor($totalLateSeconds % 60);
        $late  = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);

        return $late > 0 ? $late : '00:00:00';
    }

    public static function getEarlyLeaving($clock_out)
    {
        $endTime   = Utility::getValByName('company_end_time');
        $out = date("H:i:s", strtotime($clock_out));


        //early Leaving
        $totalEarlyLeavingSeconds = strtotime($endTime) - strtotime($out);
        $hours                    = floor($totalEarlyLeavingSeconds / 3600);
        $mins                     = floor($totalEarlyLeavingSeconds / 60 % 60);
        $secs                     = floor($totalEarlyLeavingSeconds % 60);
        $earlyLeaving             = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);

        return ($earlyLeaving > 0) ? $earlyLeaving : '00:00:00';
    }

    public static function getOvertime($clock_out)
    {
        $endTime   = Utility::getValByName('company_end_time');
        $out = date("H:i:s", strtotime($clock_out));


        if (strtotime($out) > strtotime($endTime)) {
            //Overtime
            $totalOvertimeSeconds = strtotime($out) - strtotime($endTime);
            $hours                = floor($totalOvertimeSeconds / 3600);
            $mins                 = floor($totalOvertimeSeconds / 60 % 60);
            $secs                 = floor($totalOvertimeSeconds % 60);
            $overtime             = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
        } else {
            $overtime = '00:00:00';
        }

        return $overtime;
    }
}
