@extends('pages.dashboard')

@section('dashboard-content')
<div class="page-wrapper">

    <!-- Page Content -->
    <div class="content container-fluid">

        <!-- Page Header -->
        <div class="row">
            <div class="col-md-12">
                <div class="welcome-box">
                    <div class="welcome-img">
                        <img src="https://ui-avatars.com/api/?name={{$employee->name}}" alt="">
                    </div>
                    <div class="welcome-det">
                        <h3>Welcome, {{$employee->name}}</h3>
                        <p>{{\Carbon\Carbon::now()->format('l, j F Y')}}</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Page Header -->


        <div class="row">
            <div class="col-md-4">
                <div class="card punch-status">
                    <div class="card-body">
                        <h5 class="card-title">Attendance <small class="text-muted"> {{\Carbon\Carbon::now()->format('j M Y')}}</small></h5>

                            @if ($shiftSchedule)
                                @if (!empty($attendanceStatus) && $attendanceStatus->status == 'Present')
                                    <div class="punch-det">
                                        <div class="row">
                                            <div class="col-auto">
                                                <h6>Clock In at</h6>
                                                <p> {{\Carbon\Carbon::now()->format('j M Y').' '.\Carbon\Carbon::parse($attendanceEmployee->clock_in)->format('H:i') }}</p>
                                            </div>
                                            @if (!empty($attendanceStatus) && $attendanceStatus->clock_out != '00:00:00')
                                                <div class="col-auto">
                                                    <h6>Clock Out at</h6>
                                                    <p> {{\Carbon\Carbon::now()->format('j M Y').' '.\Carbon\Carbon::parse($attendanceEmployee->clock_out)->format('H:i') }}</p>
                                                </div>
                                            @endif
                                        </div>
                                    </div>

                                @elseif (empty($attendanceStatus))

                                @endif
                            @else
                            <div class="punch-det">
                                <div class="row justify-content-center">
                                    <div class="col-auto ">
                                        <h5 class="mb-0">You don't have shift today</h5>
                                    </div>
                                </div>
                            </div>
                            @endif

                        {{-- <div class="punch-info">
                            <div class="punch-hours">
                                <span>3.45 hrs</span>
                            </div>
                        </div> --}}

                        <div class="punch-btn-section">
                            <form action="{{ route('clock_store') }}" method="post">
                                @csrf
                                <input hidden name="clock" value="{{!empty($attendanceStatus) && $attendanceStatus->status == 'Present' ? 'clock_out' : 'clock_in'}}" type="text">
                                <button {{ empty($shiftSchedule) || !empty($attendanceStatus) && $attendanceStatus->clock_out != '00:00:00' ? 'disabled' : ''}} type="submit" class="btn btn-primary punch-btn">{{!empty($attendanceStatus) && $attendanceStatus->status == 'Present' ? 'Clock Out' : 'Clock In'}} </button>
                            </form>
                        </div>

                        {{-- <div class="statistics">
                            <div class="row">
                                <div class="col-md-6 col-6 text-center">
                                    <div class="stats-box">
                                        <p>Break</p>
                                        <h6>1.21 hrs</h6>
                                    </div>
                                </div>
                                <div class="col-md-6 col-6 text-center">
                                    <div class="stats-box">
                                        <p>Overtime</p>
                                        <h6>3 hrs</h6>
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card punch-status">
                    <div class="card-body">
                        <h5 class="card-title">Timesheet <small class="text-muted"> {{\Carbon\Carbon::now()->format('j M Y')}}</small></h5>

                        @if (!is_null($timesheet))
                            <div class="punch-det">
                                <div class="row">
                                    <div class="col-auto ">
                                        <h5 class="mb-0">{{$timesheet->task_or_project}}</h5>
                                        <h6 class="mb-0">{{$timesheet->activity}}</h6>
                                    </div>
                                </div>
                            </div>
                            <div class="punch-det">
                                <div class="row">
                                    <div class="col-12 d-flex justify-content-center">
                                        <h6>Record Time</h6>
                                    </div>
                                    <div class="col-6 d-flex">
                                        <h6>Start Time</h6>
                                        <p class="ms-auto">{{is_null($timesheet->start_time) ? '00:00' : $timesheet->start_time}}</p>
                                    </div>
                                    <div class="col-6 d-flex">
                                        <h6>End Time</h6>
                                        <p class="ms-auto">{{is_null($timesheet->end_time) ? '00:00' :  $timesheet->end_time}}</p>
                                    </div>
                                </div>
                            </div>
                        @else
                        <div class="punch-det">
                                <div class="row">
                                    <div class="col-auto ">
                                        <h5 class="mb-0">You have no timesheet today</h5>
                                    </div>
                                </div>
                            </div>
                        @endif



                        <div class="punch-btn-section">
                            <form action="{{ route('timesheets.record-time') }}" method="post">
                                @csrf
                                <input hidden name="time_now" value="{{date("H:i:s")}}" type="text">
                                <button
                                 {{ is_null($timesheet) ? 'disabled' : ''}} 
                                 type="submit" class="btn btn-primary punch-btn">{{ !is_null($timesheet) ? is_null($timesheet->start_time) ? 'Start' : 'End' : 'Start'}}</button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- /Page Content -->

</div>
@endsection

@push('addon-style')
    <!-- Chart CSS -->
    <link rel="stylesheet" href="{{url('public/assets/plugins/morris/morris.css')}}">
@endpush

@push('addon-script')
    <!-- Slimscroll JS -->
    <script src="{{url('public/assets/js/jquery.slimscroll.min.js')}}"></script> --}}

     <!-- Chart JS -->
    <script src="{{url('public/assets/plugins/morris/morris.min.js')}}"></script>
    <script src="{{url('public/assets/plugins/raphael/raphael.min.js')}}"></script>
    <script src="{{url('public/assets/js/chart.js')}}"></script>
    <script src="{{url('public/assets/js/greedynav.js')}}"></script>
@endpush
