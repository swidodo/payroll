<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        
		
        
        <meta name="robots" content="noindex, nofollow">
        <title><?php echo $__env->yieldContent('title'); ?> - Pehadir</title>

		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('public/assets/img/favicon.png')); ?>">

        <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldPushContent('addon-style'); ?>

        <!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo e(url('public/assets/css/style.css')); ?>">

    </head>
    <body class="">

		<!-- Main Wrapper -->
			<?php echo $__env->yieldContent('content'); ?>
		<!-- /Main Wrapper -->

        <!-- jQuery -->
        <script src="<?php echo e(url('public/assets/js/jquery-3.6.0.min.js')); ?>"></script>

        <!-- Bootstrap Core JS -->
        <script src="<?php echo e(url('public/assets/js/bootstrap.bundle.min.js')); ?>"></script>

		
        <?php echo $__env->yieldPushContent('addon-script'); ?>

        <!-- Theme Settings JS -->
        <script src="<?php echo e(url('public/assets/js/layout.js')); ?>"></script>
        <script src="<?php echo e(url('public/assets/js/theme-settings.js')); ?>"></script>
        <script src="<?php echo e(url('public/assets/js/greedynav.js')); ?>"></script>

        <!-- Custom JS -->
        <script src="<?php echo e(url('public/assets/js/app.js')); ?>"></script>
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /home/pehadirm/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>